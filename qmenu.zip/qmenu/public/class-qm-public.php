<?php

/**
 * La funcionalidad específica de administración del plugin.
 *
 * @link       http://misitioweb.com
 * @since      1.0.0
 *
 * @package    plugin_name
 * @subpackage plugin_name/admin
 */

/**
 * Define el nombre del plugin, la versión y dos métodos para
 * Encolar la hoja de estilos específica de administración y JavaScript.
 * 
 * @since      1.0.0
 * @package    qmenu-Blank
 * @subpackage qmenu/admin
 * @author     Hostelweb <info@hostelweb.es>
 * 
 * @property string $plugin_name
 * @property string $version
 */
class qm_Public {
    
    /**
	 * El identificador único de éste plugin
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name  El nombre o identificador único de éste plugin
	 */
    private $plugin_name;
    
    /**
	 * Versión actual del plugin
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version  La versión actual del plugin
	 */
    private $version;
    
	 /**
	 * Obejeto wpdb
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      object    $db @global $wpdb
	 */
    private $db;
	
    /**
     * @param string $plugin_name nombre o identificador único de éste plugin.
     * @param string $version La versión actual del plugin.
     */
    public function __construct( $plugin_name, $version ) {
        
        $this->plugin_name  = $plugin_name;
        $this->version      = $version;     
        global $wpdb;
        $this->db= $wpdb;
    }
   /*
	 * Registra los archivos de hojas de estilos del área de administración
	 *
	 * @since    1.0.0
     * @access   public
	 */
    public function enqueue_styles() {
        
        /**
         * Una instancia de esta clase debe pasar a la función run()
         * definido en qm_Cargador como todos los ganchos se definen
         * en esa clase particular.
         *
         * El qm_Cargador creará la relación
         * entre los ganchos definidos y las funciones definidas en este
         * clase.
		 */
		wp_enqueue_style( $this->plugin_name, qm_PLUGIN_DIR_URL . 'public/css/qm-public.css', array(), $this->version, 'all' );
        
    }
    
    /**
	 * Registra los archivos Javascript del área de administración
	 *
	 * @since    1.0.0
     * @access   public
	 */
    public function enqueue_scripts() {
        
        /**
         * Una instancia de esta clase debe pasar a la función run()
         * definido en qm_Cargador como todos los ganchos se definen
         * en esa clase particular.
         *
         * El qm_Cargador creará la relación
         * entre los ganchos definidos y las funciones definidas en este
         * clase.
		 */
        wp_enqueue_script( $this->plugin_name, qm_PLUGIN_DIR_URL . 'public/js/qm-public.js', array( 'jquery' ), $this->version, true );
        
    }
	
	public function qmdatos_shortcode_id($atts, $content=''){
		$args=shortcode_atts([
			'id'=>''
		], $atts);
		
		extract($args, EXTR_OVERWRITE);
		if($id !=''){
			$sql=$this->db->prepare("SELECT  distinct nombre, data, comments FROM ". QM_TABLE. " WHERE id= %d ", $id);
			$resultado=$this->db->get_results($sql);
			if($resultado[0]->data !=''){
				
				$data=json_decode($resultado[0]->data, true);
				$output.="<div class='row'>";
				$output.="<h5><strong> PRIMEROS</strong></h5><hr/>";
				foreach($data as $v){
					foreach($v as $i){
						if($i['primeros']!=null){
						
						$output.= "<div class='col s7' style='margin-top:3px'>".$i['plato'];
						if($i['gluten']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/gluten.png'"." height='30' width='30'"."/></div>";
						}
						
						if($i['pescado']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/pescado.png'"." height='30' width='30'"."/></div>";
						}
						if($i['huevo'] !=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/huevo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['soja']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/soja.png'"." height='30' width='30'"."/></div>";
						}
						if($i['lactosa']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/leche-lactosa.png'"." height='30' width='30'"."/></div>";
						}
							
						if($i['crustaceo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/cristaceos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['cacahuete']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/cacahuetes.png'"." height='30' width='30'"."/></div>";
						}
						if($i['apio']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/apio.png'"." height='30' width='30'"."/></div>";
						}
						if($i['mostaza']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/mostaza.png'"." height='30' width='30'"."/></div>";
						}
						if($i['sesamo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/sesamo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['frutos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/frutos secos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['altramuces']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/atramuces.png'"." height='30' width='30'"."/></div>";
						}
						if($i['moluscos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/moluscos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['azufre']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'"." height='30' width='30'"."/></div>";
						}
							$output.="</div>";
					
						}
						
					}
				}
				$output.="</br><h5><strong>SEGUNDOS</strong></h5><hr/>";
				foreach($data as $v){
					foreach($v as $i){
						if($i['segundos']!=null){
						
						$output.= "<div class='col s7' style='margin-top:3px'>".$i['plato'];
						if($i['gluten']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/gluten.png'"." height='30' width='30'"."/></div>";
						}
						
						if($i['pescado']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/pescado.png'"." height='30' width='30'"."/></div>";
						}
						if($i['huevo'] !=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/huevo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['soja']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/soja.png'"." height='30' width='30'"."/></div>";
						}
						if($i['lactosa']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/leche-lactosa.png'"." height='30' width='30'"."/></div>";
						}
							
						if($i['crustaceo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/cristaceos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['cacahuete']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/cacahuetes.png'"." height='30' width='30'"."/></div>";
						}
						if($i['apio']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/apio.png'"." height='30' width='30'"."/></div>";
						}
						if($i['mostaza']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/mostaza.png'"." height='30' width='30'"."/></div>";
						}
						if($i['sesamo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/sesamo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['frutos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/frutos secos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['altramuces']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/atramuces.png'"." height='30' width='30'"."/></div>";
						}
						if($i['moluscos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/moluscos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['azufre']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'"." height='30' width='30'"."/></div>";
						}
							$output.="</div>";
					}
						
					}
				}
				$output.="</br><h5><strong> POSTRES</strong></h5><hr/>";
				foreach($data as $v){
					foreach($v as $i){
						if($i['postres']!=null){
						
						$output.= "<div class='col s7' style='margin-top:3px'>".$i['plato'];
						if($i['gluten']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/gluten.png'"." height='30' width='30'"."/></div>";
						}
						
						if($i['pescado']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/pescado.png'"." height='30' width='30'"."/></div>";
						}
						if($i['huevo'] !=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/huevo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['soja']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/soja.png'"." height='30' width='30'"."/></div>";
						}
						if($i['lactosa']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/leche-lactosa.png'"." height='30' width='30'"."/></div>";
						}
							
						if($i['crustaceo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/imgcristaceos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['cacahuete']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/cacahuetes.png'"." height='30' width='30'"."/></div>";
						}
						if($i['apio']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/apio.png'"." height='30' width='30'"."/></div>";
						}
						if($i['mostaza']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/mostaza.png'"." height='30' width='30'"."/></div>";
						}
						if($i['sesamo']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/sesamo.png'"." height='30' width='30'"."/></div>";
						}
						if($i['frutos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/frutos secos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['altramuces']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/atramuces.png'"." height='30' width='30'"."/></div>";
						}
						if($i['moluscos']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/moluscos.png'"." height='30' width='30'"."/></div>";
						}
						if($i['azufre']!=null){
							$output.="<div class='separator'><img src='".site_url()."/wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'"." height='30' width='30'"."/></div>";
						}
							$output.="</div>";
					}
						
					}
				}
			}
			
		}
		/*$output.="</div>";*/
		$comments=json_decode($resultado[0]->comments, true);
		foreach($comments as $v){
				if($v['precio']!=null){
							$output.="<div class='comments'><span>".$v['precio']."€</span></div>";
				}
				if($v['cafe']=='on'){
					$output.="<div class='comments'><strong>Incluye Café</strong></div>";
				}
				if($v['bebida']=='on'){
					$output.="<div class='comments'><strong>Incluye Bebida y Pan</strong></div>";
				}
				if($v['extras']!=null){
					$output.="<div class='comments'>".$v['extras']."</div>";
				}
		}
		$output.="</div></div>";
		return $output;
		
	}
		
			
}
	
	








