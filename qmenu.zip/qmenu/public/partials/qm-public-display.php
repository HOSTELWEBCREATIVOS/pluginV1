<?php

/**
  * Proporcionar una vista del lado del cliente/público para el plugin.
  *
  * Este archivo se utiliza para marcar los aspectos del lado del cliente/público para el plugin
  *
  * @link http://misitioweb.com
  * @since desde 1.0.0
  *
  * @package qmenu_blank
  * @subpackage qmenu/public/parcials
  */
?>

<!-- Este archivo debe consistir principalmente en HTML con un poco de PHP. -->
