<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                http://hostelweb.es
 * @since               1.0.0
 * @package             qmenu
 *
 * @wordpress-plugin
 * Plugin Name:         Qmenu
 * Plugin URI:          http://qmenu.es
 * Description:         Este plugin tiene el objetivo de aportar comodidad para ti. Anunciar el menú del día de tu local dejará de ser un problema.
 * Version:             1.0.0
 * Author:              Hostelweb
 * Author URI:          http://hostelwerb.es
 * License:             GPL2
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         hostelweb-textdomain
 * Domain Path:         /languages
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}
global $wpdb;
define( 'qm_REALPATH_BASENAME_PLUGIN', dirname( plugin_basename( __FILE__ ) ) . '/' );
define( 'qm_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );
define( 'qm_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'qm_TABLE', "{$wpdb->prefix}hostelweb_data" );

/**
 * Código que se ejecuta en la activación del plugin
 */
function activate_beziercode_blank() {
    require_once qm_PLUGIN_DIR_PATH . 'includes/class-qm-activator.php';
	qm_Activator::activate();
}

/**
 * Código que se ejecuta en la desactivación del plugin
 */
function deactivate_beziercode_blank() {
    require_once qm_PLUGIN_DIR_PATH . 'includes/class-qm-deactivator.php';
	qm_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_beziercode_blank' );
register_deactivation_hook( __FILE__, 'deactivate_beziercode_blank' );

require_once qm_PLUGIN_DIR_PATH . 'includes/class-qm-master.php';

function run_qm_master() {
    $qm_master = new qm_Master;
    $qm_master->run();
}

run_qm_master();
























