<?php
require_once 'pdf.php';
ob_end_clean();
	ob_start();
        define('EURO',chr(128));
		$pdf = new PDF();
        $pdf->AddPage('L');
		$pdf->Image('admin/img/marco-menu-horizontal.jpg',6,7,285,195);
		$pdf->Image('admin/img/logo.png',220,150,30,30);
		$pdf->Image('admin/img/informacion-alergenos-qmenu.jpg',35,150,100,29);
		$pdf->SetFont( 'Times', 'B', 14 );
		$pdf->Ln(11);
		$pdf->MultiCell(0,10, 'DIPONIBLE YA EN NUESTRA WEB losamigosrestaurante.es ',0 ,'C');
		$pdf->SetFont( 'Times', 'B', 38 );
		$pdf->Ln (25);
        $pdf->MultiCell(0,10, 'PRIMEROS',0 ,'C');
		$pdf->Ln(3);
		$pdf->SetFont('Helvetica','', 26 );
		categoriaPrimeros();
		$pdf->SetXY(35,179);
		$pdf->SetFont( 'Times', 'B', 9 );
		$pdf->MultiCell(0,10,utf8_decode('*Establecimiento con información disponible en materia de alergias e intolerancias alimentarias, soliciten información a nuestro personal'),0 ,'L');
		$pdf->AddPage('L');
		$pdf->Image('admin/img/marco-menu-horizontal.jpg',6,7,285,195);
		$pdf->Image('admin/img/logo.png',220,150,30,30);
		
		$pdf->Ln(12);
		$pdf->SetFont( 'Times','B', 38 );
		$pdf->MultiCell(0,10, 'SEGUNDOS',0 ,'C');
		$pdf->Ln(3);
		$pdf->SetFont( 'Arial','', 26 );
		categoriaSegundos();
		$pdf->Ln();
		$pdf->SetFont( 'Times', 'B', 38 );
        $pdf->MultiCell(0,8, 'POSTRES',0 ,'C');
		$pdf->Ln(3);
		$pdf->SetFont('Arial','',26);
		categoriaPostres();
		$pdf->Ln();
		categoriaExtras();
		$pdf->Output();
		
	function categoriaPrimeros(){
		global $pdf;
		$platos=$pdf->primerosPlatosVertical($_GET['id']);
		//$pdf->SetXY(60,30);
		$pdf->MultiCell (0,11,utf8_decode($platos),0,'C' );
		
		//categoriaPrimerosUno();
		 }
	
	function categoriaSegundos(){
		global $pdf;
		$platos=$pdf->segundosPlatosVertical($_GET['id']);
		$primeros=$pdf->consultarPlatos($_GET['id']);
		$cuanto=0;
		/*foreach( $primeros->items as $v){
				if($v->segundos){
					$cuanto++;
				}
			}
		if ($cuanto==4){
			$pdf->SetXY(60,75);
		}else{
			if( $cuanto==3){
			$pdf->SetXY(60,67);
			}
			if($cuanto==2){
			$pdf->SetXY(60,59);
			}
		}*/
		
		$pdf->MultiCell (0,11,utf8_decode($platos),0,'C' );
		
		//categoriaSegundosUno();
		
		 }

	function categoriaPostres(){
		global $pdf;
		$platos=$pdf->postresPlatosVertical($_GET['id']);
		$primeros=$pdf->consultarPlatos($_GET['id']);
		$cuanto=0;
		/*foreach($primeros->items as $v){
				if($v->postres){
					$cuanto++;
				}
			}
		if ($cuanto==4){
			$pdf->SetXY(60,120);
		}else{
			if( $cuanto==3){
			$pdf->SetXY(60,107);
			}
			if($cuanto==2){
			$pdf->SetXY(60,100);
			}*/
			
		$pdf->MultiCell(0,11,utf8_decode($platos),0,'C');
		//categoriaPostresUno();
		}
	
	function categoriaExtras(){
				global $pdf;
				$pdf->SetFont( 'Arial', 'B', 34 );
				$extras=$pdf->precioObservaciones($_GET['id']);
				$pdf->MultiCell(0,8,utf8_decode($extras).EURO,0,'C');
				$cafe=$pdf->observacionesCafe($_GET['id']);
				$pdf->SetFont( 'Arial', '', 14 );
				$comentario=$pdf->observacionesExtras($_GET['id']);
				$pdf->Ln(2);
				if($comentario !=null){
					$pdf->MultiCell(0,8,utf8_decode($comentario)."",0,'C');
				}
	}

function categoriaPrimerosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
				$cnt=30;
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->primeros){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',210,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',210,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',220,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',230,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',240,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}

	function categoriaSegundosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuanto++;
				}
			}
			if($cuanto==3){
				$cnt=67;
			}else{
				if($cuanto==4){
				$cnt=75;
				}
				if($cuanto==2){
					$cnt=59;
				}
			}
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->segundos){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',210,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',210,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',220,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',230,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',240,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}
	function categoriaPostresUno(){
				global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			$cuanto="";
			$cuantoPrimero="";
			foreach( $primeros->items as $v){
				if($v->segundos){
					$cuanto++;
				}
			}
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuantoPrimero++;
				}
			}
			if($cuantoPrimero==4){
			if($cuanto==3){
				$cnt=110;
			}else{
				if($cuanto==4){
				$cnt=120;
				}
				if($cuanto==2){
					$cnt=100;
				}
			}
			}
			
			if($cuantoPrimero==3){
			if($cuanto==3){
				$cnt=105;
			}else{
				if($cuanto==4){
				$cnt=95;
				}
				if($cuanto==2){
					$cnt=85;
				}
			}
			}
			
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->postres){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',210,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',210,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',220,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',230,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',240,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}		
		}




		
?>