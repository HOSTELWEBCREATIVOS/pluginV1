<?php
require_once 'pdf.php';
ob_end_clean();
	ob_start(); 
		$pdf = new FPDF();
        define('EURO',chr(128));
		$pdf = new PDF();
        $pdf->AddPage('L');
		$pdf->Image('admin/img/marco-menu-vertical1.jpg',7,7,140,198);
		$pdf->Image('admin/img/marco-menu-vertical1.jpg',152,7,139.5,198);
		$pdf->SetFont( 'Arial', 'B', 18 );
		$pdf->Ln (6);
        $pdf->MultiCell(130,7, 'PRIMEROS',0 ,'C');
		$pdf->SetFont( 'Arial','', 12);
		categoriaPrimeros();
		$pdf->Ln(12);
		$pdf->SetFont( 'Arial', 'B', 18 );
        $pdf->MultiCell(130,7, 'SEGUNDOS',0 ,'C');
		$pdf->SetFont( 'Arial','',12 );
		categoriaSegundos();
		$pdf->SetFont( 'Arial', 'B', 18 );
		$pdf->Ln (10);
        $pdf->MultiCell(130,7, 'POSTRES',0 ,'C');
		$pdf->SetFont( 'Arial','', 12);
		categoriaPostres();
		$pdf->SetFont( 'Arial','', 12 );
		$pdf->Ln(10);
		tienePrecio();
		//tieneCafe();
		//tieneBebida();
		tieneComentarios();
		$pdf->setXY(25,174);
		$pdf->Image('admin/img/informacion-alergenos-qmenu.jpg',40,150,65,20);
		$pdf->Ln(1);
		$pdf->SetFont( 'Arial','', 6 );
		$pdf->MultiCell(135,5,utf8_decode('*Establecimiento con información disponible en materia de alergias e intolerancias alimentarias,información a nuestro personal'),0 ,'C');		
		$pdf->SetFont( 'Arial','B', 12 );		
		$pdf->MultiCell(135,5, 'DIPONIBLE YA EN NUESTRA WEB losamigosrestaurante.es ',0 ,'C');
		$pdf->setXY(160,16);
		$pdf->SetFont( 'Arial', 'B', 18 );
		$pdf->Multicell(130,7, 'PRIMEROS',0 ,'C');
		$pdf->SetFont( 'Arial','', 12 );
		$pdf->setXY(160,23);
		categoriaPrimeros();
		$pdf->setXY(160,66);
		$pdf->SetFont( 'Arial', 'B', 18 );
		
        $pdf->MultiCell(130,7, 'SEGUNDOS',0 ,'C');
		$pdf->setXY(160,73);
		$pdf->SetFont( 'Arial','', 12 );
		categoriaSegundos();
		$pdf->setXY(160,119);
		$pdf->SetFont( 'Arial', 'B', 18 );
        $pdf->MultiCell(130,7, 'POSTRES',0 ,'C');
		$pdf->SetFont( 'Arial','', 12 );
		$pdf->setXY(160,125);
		categoriaPostres();
		$pdf->SetFont( 'Arial','', 12 );
		$pdf->setXY(160,135);
		tienePrecio();
		$pdf->setXY(160,156);
		tieneComentarios();
		$pdf->setXY(160,174);
		$pdf->Image('admin/img/informacion-alergenos-qmenu.jpg',190,150,65,20);
		//$pdf->Ln(1);
		$pdf->SetFont( 'Arial','', 6 );
		$pdf->MultiCell(125,5,utf8_decode('*Establecimiento con información disponible en materia de alergias e intolerancias alimentarias,información a nuestro personal'),0 ,'C');
		$pdf->SetFont( 'Arial','B', 12 );
		$pdf->setXY(160,180);
		$pdf->MultiCell(125,5, 'DIPONIBLE YA EN NUESTRA WEB losamigosrestaurante.es ',0 ,'C');
		$pdf->Output();
		ob_end_flush();

		function categoriaPrimeros(){
		global $pdf;
		$platos=$pdf->primerosPlatosVertical($_GET['id']);

		$pdf->MultiCell (130,6,utf8_decode($platos),0,'C' );
		
		//categoriaPrimerosUno();
		//categoriaPrimerosDos();
		
		 }
		function categoriaSegundos(){
		global $pdf;
		$platos=$pdf->segundosPlatosVertical($_GET['id']);
		
		$pdf->MultiCell (130,6,utf8_decode($platos),0,'C' );
		
		//categoriaSegundosUno();
		//categoriaSegundosDos();
		
		 }

	function categoriaPrimerosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
				$cnt=25;
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->primeros){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',140,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',110,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',120,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',130,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',140,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}

	function categoriaPrimerosDos(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
				$cnt=25;
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->primeros){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',140,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',260,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',270,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',280,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',290,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}

		function categoriaSegundosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuanto++;
				}
			}
			if($cuanto==3){
				$cnt=60;
			}else{
				if($cuanto==4){
				$cnt=67;
				}
				if($cuanto==2){
					$cnt=53;
				}
			}
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->segundos){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',110,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',110,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',120,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',130,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',140,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}

	function categoriaSegundosDos(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuanto++;
				}
			}
				if($cuanto==3){
					
				$cnt=60;
			}else{
				if($cuanto==4){
				
				$cnt=67;
				}
				if($cuanto==2){
					
					$cnt=53;
				}
			}
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->segundos){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',140,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',260,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',270,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',280,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',290,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}
function categoriaPostresUno(){
				global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			$cuanto="";
			$cuantoPrimero="";
			foreach( $primeros->items as $v){
				if($v->segundos){
					$cuanto++;
				}
			}
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuantoPrimero++;
				}
			}
			if($cuantoPrimero==4){
			if($cuanto==3){
				$cnt=100;
			}else{
				if($cuanto==4){
				$cnt=109;
				}
				if($cuanto==2){
					$cnt=91;
				}
			}
			}
			
			if($cuantoPrimero==3){
			if($cuanto==3){
				$cnt=93;
			}else{
				if($cuanto==4){
				$cnt=75;
				}
				if($cuanto==2){
					$cnt=105;
				}
			}
			}
			
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->postres){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',110,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',110,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',120,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',130,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',140,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}		
		}

		function categoriaPostresDos(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
				foreach( $primeros->items as $v){
				if($v->segundos){
					$cuanto++;
				}
			}
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuantoPrimero++;
				}
			}
				if($cuantoPrimero==4){
			if($cuanto==3){
				$cnt=100;
			}else{
				if($cuanto==4){
				$cnt=109;
				}
				if($cuanto==2){
					$cnt=91;
				}
			}
			}
			
			if($cuantoPrimero==3){
			if($cuanto==3){
				$cnt=93;
			}else{
				if($cuanto==4){
				$cnt=75;
				}
				if($cuanto==2){
					$cnt=105;
				}
			}
			}
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->postres){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',140,$cnt,8,8);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',260,$cnt,8,8);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',270,$cnt,8,8);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',280,$cnt,8,8);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',290,$cnt,8,8);
				}
				 $cnt=$cnt+8;
						
					}
					}
				}
		}

			function categoriaPostres(){
				global $pdf;
				$platos=$pdf->postresPlatosVertical($_GET['id']);
				$pdf->MultiCell(130,6,utf8_decode($platos),0,'C');
				//categoriaPostresUno();
				//categoriaPostresDos();
			}

		
			function tienePrecio(){
				global $pdf;
				$pdf->SetFont( 'Arial', 'B', 25 );
				$extras=$pdf->precioObservaciones($_GET['id']);
				$iva=$pdf->ivaprecio($_GET['id']);
				
				if($iva !=null){
					$pdf->MultiCell(130,6,utf8_decode($extras).EURO,0,'C');
				}else{
					$pdf->MultiCell(130,6,utf8_decode($extras).EURO,0,'C');
				}
				
				$pdf->Ln(0.5);
			}
			function tieneCafe(){
				global $pdf;
				$cafe=$pdf->observacionesCafe($_GET['id']);
				$pdf->SetFont( 'Arial', '', 7 );
				if($cafe !=null){
					$pdf->MultiCell(130,5,utf8_decode("Incluye Café"),0,'C');
				}
			}
			function tieneBebida(){
				global $pdf;
				$cafe=$pdf->observacionesCafe($_GET['id']);
				$pdf->SetFont( 'Arial', '', 7 );
				
				$bebida=$pdf->observacionesBebida($_GET['id']);
				if($bebida !=null){
					$pdf->MultiCell(130,5,"Incluye Bebida y Pan",0,'C');
				}
				
			}
			function tieneComentarios(){
				global $pdf;
				$cafe=$pdf->observacionesCafe($_GET['id']);
				$pdf->SetFont( 'Arial', '', 7 );
				$comentario=$pdf->observacionesExtras($_GET['id']);
				
				if($comentario !=null){
					$pdf->MultiCell(130,5,utf8_decode($comentario)."",0,'C');
				}
			}


			

?>