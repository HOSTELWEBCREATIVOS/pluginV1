<?php

/**
 * Define la funcionalidad de internacionalización
 *
 * Carga y define los archivos de internacionalización de este plugin para que esté listo para su traducción.
 *
 * @link       http://qmenu.es
 * @since      1.0.0
 *
 * @package    qmenu
 * @subpackage qmenu/includes
 */

/**
 * Ésta clase define todo lo necesario durante la activación del plugin
 *
 * @since      1.0.0
 * @package    qmenu
 * @subpackage qmenu/includes
 * @author     Hostelweb <info@hostelweb.es>
 */
class qm_i18n {
    
    /**
	 * Carga el dominio de texto (textdomain) del plugin para la traducción.
	 *
     * @since    1.0.0
     * @access public static
	 */    
    public function load_plugin_textdomain() {
        
        load_plugin_textdomain(
            'hostelweb-textdomain',
            false,
            qm_PLUGIN_DIR_PATH . 'languages'
        );
        
    }
    
}