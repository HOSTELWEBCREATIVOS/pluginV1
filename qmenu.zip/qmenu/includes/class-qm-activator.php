<?php

/**
 * Se activa en la activación del plugin
 *
 * @link       http://hostelweb.es
 * @since      1.0.0
 *
 * @package    qmenu
 * @subpackage qmenu/includes
 */

/**
 * Ésta clase define todo lo necesario durante la activación del plugin
 *
 * @since      1.0.0
 * @package    qmenu
 * @subpackage qmenu/includes
 * @author     Hostelweb <info@hostelweb.es>
 */
class qm_Activator {

	/**
	 * Método estático que se ejecuta al activar el plugin
	 *
	 * Creación de la tabla {$wpdb->prefix}beziercode_data
     * para guardar toda la información necesaria
	 *
	 * @since 1.0.0
     * @access public static
	 */
	public static function activate() {
        
        //nombre de la tabla
        global $wpdb;
        $sql="CREATE TABLE if not exists ".QM_TABLE."(
        id int auto_increment NOT null,
        nombre varchar(50) not null,
        data longtext not null,
		comments longtext not null,
        primary key (id)
        );";
        $wpdb->query($sql);
        
	}

}





