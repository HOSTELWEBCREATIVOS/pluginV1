<?php

/**
 * La funcionalidad específica de simular un CRUD
 *
 * @link       http://hostelweb.es
 * @since      1.0.0
 *
 * @package    qmenu
 * @subpackage qmenu/admin
 */

/**
 * Define el nombre del plugin, la versión y dos métodos para
 * Encolar la hoja de estilos específica de administración y JavaScript.
 * 
 * @since      1.0.0
 * @package    qmenu
 * @subpackage qmenu/admin
 * @author     Hostelweb<info@hostelweb.es>
 * 
 * @property string $plugin_name
 * @property string $version
 */

class QM_JSON{
		
	private $cnt;
		/**
	 * Permite crear la estructura base para poder guardar  los datos de *los items con el formato JSON
	 *
	 * @since    1.0.0
	 * @access   public
	 *@param 	 string $data	El valor obtenido del campo 'data' con el formato JSON
	 *@param 	 string $plato1	 	Nombre del plato1
	 *@param 	 string $plato2	 	Nombre del plato2
	 *@param 	 string $plato3	 	Nombre del plato3
	 *@param 	 string $plato4	 	Nombre del plato4
	 *@param 	 string $plato5	 	Nombre del plato5
	 *@param 	 string $plato6	 	Nombre del plato6
	 *@param 	 string $plato7	 	Nombre del plato7
	 *@param 	 string $plato8	 	Nombre del plato8
	 *@param 	 string $plato9	 	Nombre del plato9
	 *@param 	 string $plato10	Nombre del plato10
	 *@param 	 string $plato11	Nombre del plato11
	 *@param 	 string $plato12	Nombre del plato12
	 *
	 */
	 
	public function __construct(){
        $this->cnt= 1;
    }
	
	public function add_comment_prof($data,$precio,$cafe,$bebida,$iva,$extras){
		if($data ==''){
		$data=[
				"items"=>[
				"id"=>1,
				"precio"=>$precio,
				"cafe"=>$cafe,
				"bebida"=>$bebida,
				"iva"=>$iva,
				"extras"=>$extras
			]
		];
		
		
		return $data;
	}
	}
	
	 public function add_item_prof ($data,$plato,$gluten,$pescado,$huevo,$soja,$lactosa,$crustaceo,$cacahuete,$frutos,$apio,$mostaza,$sesamo,$altramuces,$moluscos,$azufre,$primeros,$segundos,$postres){
		 if($data ==''){
			 $data=[
				"tabla"=>[
					"nombre"=>''
				],"items"=>[
					[
						"id"=>1,
						"plato"=>$plato,
						"gluten"=>$gluten,
						"pescado"=>$pescado,
						"huevo"=>$huevo,
						"soja"=>$soja,
						"lactosa"=>$lactosa,
						"crustaceo"=>$crustaceo,
						"cacahuete"=>$cacahuete,
						"frutos"=>$frutos,
						"apio"=>$apio,
						"mostaza"=>$mostaza,
						"sesamo"=>$sesamo,
						"altramuces"=>$altramuces,
						"moluscos"=>$moluscos,
						"azufre"=>$azufre,
						"moluscos"=>$moluscos,
						"primeros"=>$primeros,
						"segundos"=>$segundos,
						"postres"=>$postres
					]
				]
			];
		 }else{			$items_decode= json_decode( $data, true);
						$last_item=end($items_decode['items']);
						$last_item_id= $last_item['id'];
						$insert_item_id= ++$last_item_id;
			 			$items_decode['items'][]=[
						"id"=>$insert_item_id,
						"plato"=>$plato,
						"gluten"=>$gluten,
						"pescado"=>$pescado,
						"huevo"=>$huevo,
						"soja"=>$soja,
						"lactosa"=>$lactosa,
						"crustaceo"=>$crustaceo,
						"cacahuete"=>$cacahuete,
						"frutos"=>$frutos,
						"apio"=>$apio,
						"mostaza"=>$mostaza,
						"sesamo"=>$sesamo,
						"altramuces"=>$altramuces,
						"moluscos"=>$moluscos,
						"azufre"=>$azufre,
						"moluscos"=>$moluscos,
						"primeros"=>$primeros,
						"segundos"=>$segundos,
						"postres"=>$postres
						];
						$data=$items_decode;
		 }
		 
		 return $data;
	 }
	
	public function read_item_prof($data, $cnt){
		
		if($data !=''){
			
			//$cnt=$this->cnt;
			$output="";
			foreach($data as $v){
				$data=json_decode($v->{'data'});
				$items=$data->{"items"};
				foreach($items as $i){
					if($i->{"primeros"}!=null){
					$cnt=$i->{"id"};
					$plato=$i->{"plato"};
					$gluten=$i->{"gluten"};
					$pescado=$i->{"pescado"};
					$crustaceo=$i->{"crustaceo"};
					$huevo=$i->{"huevo"};
					$soja=$i->{"soja"};
					
					$lactosa=$i->{"lactosa"};
					$cacahuete=$i->{"cacahuete"};
					$frutos=$i->{"frutos"};
					$apio=$i->{"apio"};
					$mostaza=$i->{"mostaza"};
					$sesamo=$i->{"sesamo"};
					$altramuces=$i->{"altramuces"};
					$moluscos=$i->{"moluscos"};
					$dioxido=$i->{"dioxido de azufre"};
					$output.="
						<h6 data-plate='$cnt'/>
						<div style='display:inline-flex;margin-bottom:25px;'>
						<h6 id='plato$cnt' type='primeros'>$plato</h6>";
						
						if($gluten !=null){
							$output.="<div  id='gluten$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/gluten.png'".'height="25" width="25"/></div>';
						}
						if($pescado!=null){
							$output.="<div  id='pescado$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/pescado.png'".'height="25" width="25"/></div>';
						}
						
						if($crustaceo!=null){
							$output.="<div  id='crustaceo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cristaceos.png'".'height="25" width="25"/></div>';
						}
						if($huevo !=null){
							$output.="<div  id='huevo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/huevo.png'".'height="25" width="25"/></div>';
						}
						if($soja!=null){
							$output.="<div  id='soja$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/soja.png'".'height="25" width="25"/></div>';
						}
						if($lactosa!=null){
							$output.="<div id='lactosa$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/leche-lactosa.png'".'height="25" width="25"/></div>';
						}
						
						if($frutos!=null){
							$output.="<div id='frutos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/frutos secos.png'".'height="25" width="25"/></div>';
						}
						if($cacahuete!=null){
							$output.="<div id='cacahuete$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cacahuetes.png'".'height="25" width="25"/></div>';
						}
						if($apio!=null){
							$output.="<div  id='apio$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/apio.png'".'height="25" width="25"/></div>';
						}
						if($mostaza!=null){
							$output.="<div  id='mostaza$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/mostaza.png'".'height="25" width="25"/></div>';
						}
						if($sesamo!=null){
							$output.="<div  id='sesamo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/sesamo.png'".'height="25" width="25"/></div>';
						}
						
						if($altramuces!=null){
							$output.="<div id='altramuces$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/atramuces.png'".'height="25" width="25"/></div>';
						}
						if($moluscos!=null){
							$output.="<div id='mosluscos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/moluscos.png'".'height="25" width="25"/></div>';
						}
						if($dioxido!=null){
							$output.="<div id='dioxido$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'".'height="25" width="25"/></div>';
						}
						
						$output.="</div>";
						
									
						$output.="</br>";
						//$cnt++;
					}
				}		
			}
		}
		$this->cnt=$cnt;
		return $output;
	}
	public function read_item_prof_second($data,$cnt){
		if($data !=''){
			
			//$cnt=$this->cnt;
			$output="";
			
			foreach($data as $v){
				$data=json_decode($v->{'data'});
				$items=$data->{"items"};
				foreach($items as $i){
					
					if($i->{"segundos"}!=null){
					$cnt=$i->{"id"};
					$plato=$i->{"plato"};
					$gluten=$i->{"gluten"};
					$pescado=$i->{"pescado"};
					$crustaceo=$i->{"crustaceo"};
					$huevo=$i->{"huevo"};
					$soja=$i->{"soja"};
					$lactosa=$i->{"lactosa"};
					$cacahuete=$i->{"cacahuete"};
					$frutos=$i->{"frutos"};
					$apio=$i->{"apio"};
					$mostaza=$i->{"mostaza"};
					$sesamo=$i->{"sesamo"};
					$altramuces=$i->{"altramuces"};
					$moluscos=$i->{"moluscos"};
					$dioxido=$i->{"dioxido de azufre"};
					$output.=" <h6 data-plate='$cnt'/><div style='display:inline-flex;margin-bottom:25px;'>
						<h6 id='plato$cnt' type='segundos'>$plato</h6>";
						
						if($gluten !=null){
							$output.="<div  id='gluten$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/gluten.png'".'height="25" width="25"/></div>';
						}
						if($pescado!=null){
							$output.="<div  id='pescado$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/pescado.png'".'height="25" width="25"/></div>';
						}
						
						if($crustaceo!=null){
							$output.="<div  id='crustaceo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cristaceos.png'".'height="25" width="25"/></div>';
						}
						if($huevo !=null){
							$output.="<div  id='huevo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/huevo.png'".'height="25" width="25"/></div>';
						}
						if($soja!=null){
							$output.="<div  id='soja$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/soja.png'".'height="25" width="25"/></div>';
						}
						if($lactosa!=null){
							$output.="<div id='lactosa$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/leche-lactosa.png'".'height="25" width="25"/></div>';
						}
						
						if($frutos!=null){
							$output.="<div id='frutos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/frutos secos.png'".'height="25" width="25"/></div>';
						}
						if($cacahuete!=null){
							$output.="<div id='cacahuete$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cacahuetes.png'".'height="25" width="25"/></div>';
						}
						if($apio!=null){
							$output.="<div  id='apio$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/apio.png'".'height="25" width="25"/></div>';
						}
						if($mostaza!=null){
							$output.="<div  id='mostaza$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/mostaza.png'".'height="25" width="25"/></div>';
						}
						if($sesamo!=null){
							$output.="<div  id='sesamo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/sesamo.png'".'height="25" width="25"/></div>';
						}
						
						if($altramuces!=null){
							$output.="<div id='altramuces$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/atramuces.png'".'height="25" width="25"/></div>';
						}
						if($moluscos!=null){
							$output.="<div id='mosluscos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/moluscos.png'".'height="25" width="25"/></div>';
						}
						if($dioxido!=null){
							$output.="<div id='dioxido$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'".'height="25" width="25"/></div>';
						}
						
						$output.="</div>";
						
									
						$output.="</br>";
						//$cnt++;
						
					}
				}		
			}
		}
		$this->cnt=$cnt;
		return $output;
	}
	
	public function read_item_prof_third($data, $cnt){
		if($data !=''){
			//$cnt=$this->cnt;
			$output="";
			foreach($data as $v){
				$data=json_decode($v->{'data'});
				$items=$data->{"items"};
				foreach($items as $i){
					if($i->{"postres"}!=null){
					$cnt=$i->{"id"};
					$plato=$i->{"plato"};
					$gluten=$i->{"gluten"};
					$pescado=$i->{"pescado"};
					$crustaceo=$i->{"crustaceo"};
					$huevo=$i->{"huevo"};
					$soja=$i->{"soja"};
					$lactosa=$i->{"lactosa"};
					$cacahuete=$i->{"cacahuete"};
					$frutos=$i->{"frutos"};
					$apio=$i->{"apio"};
					$mostaza=$i->{"mostaza"};
					$sesamo=$i->{"sesamo"};
					$altramuces=$i->{"altramuces"};
					$moluscos=$i->{"moluscos"};
					$dioxido=$i->{"dioxido de azufre"};
					$output.="<h6 data-plate='$cnt'/><div style='display:inline-flex;margin-bottom:25px;'>
						<h6 id='plato$cnt' type='postres'>$plato</h6>";
						
						if($gluten !=null){
							$output.="<div  id='gluten$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/gluten.png'".'height="25" width="25"/></div>';
						}
						if($pescado!=null){
							$output.="<div  id='pescado$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/pescado.png'".'height="25" width="25"/></div>';
						}
						
						if($crustaceo!=null){
							$output.="<div  id='crustaceo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cristaceos.png'".'height="35" width="25"/></div>';
						}
						if($huevo !=null){
							$output.="<div  id='huevo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/huevo.png'".'height="25" width="25"/></div>';
						}
						if($soja!=null){
							$output.="<div  id='soja$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/soja.png'".'height="25" width="25"/></div>';
						}
						if($lactosa!=null){
							$output.="<div id='lactosa$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/leche-lactosa.png'".'height="25" width="25"/></div>';
						}
						
						if($frutos!=null){
							$output.="<div id='frutos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/frutos secos.png'".'height="25" width="25"/></div>';
						}
						if($cacahuete!=null){
							$output.="<div id='cacahuete$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cacahuetes.png'".'height="25" width="25"/></div>';
						}
						if($apio!=null){
							$output.="<div  id='apio$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/apio.png'".'height="25" width="25"/></div>';
						}
						if($mostaza!=null){
							$output.="<div  id='mostaza$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/mostaza.png'".'height="25" width="25"/></div>';
						}
						if($sesamo!=null){
							$output.="<div  id='sesamo$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/sesamo.png'".'height="25" width="25"/></div>';
						}
						
						if($altramuces!=null){
							$output.="<div id='altramuces$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/atramuces.png'".'height="25" width="25"/></div>';
						}
						if($moluscos!=null){
							$output.="<div id='mosluscos$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/moluscos.png'".'height="25" width="25"/></div>';
						}
						if($dioxido!=null){
							$output.="<div id='dioxido$cnt' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png'".'height="25" width="25"/></div>';
						}
						
						$output.="</div>";
						
									
						$output.="</br>";
						$cnt++;
					}
				}		
			}
		}
		
		return $output;
	}
	
	  /**
	 * Permite convertir lso items con el formato JSON
	 *a un array par aluego ser iterados con 'foreach'
	 *para ir generando el código HTML con todos los datos de los items a mostrar
	 *
	 *@since    1.0.0
	 *@access   public
	 *@param 	 String $data El valor obtenido del campo 'data' con el formato JSON
	 *@return	 Retorna el $output con el HTML generado de todos los items a mostrar
	 */
	
	public function read_item($data){
		
		if($data !=''){
			$data=json_decode($data, true);
			$output='';
			foreach($data['items'] as $v){
				$id=$v['id'];
				$plato1=$v['plato'+$cnt];
				$plato2=$v['plato2'];
				$plato3=$v['plato3'];
				$plato4=$v['plato4'];
				$output.="
				<tr data-item='$id'>
					<td>$plato1</td>					
				</tr>
				<tr>
					<td>$plato2</td>
				</tr>
				<tr>
					<td>$plato3</td>
				</tr>
				<tr>
					<td>$plato4</td>
				</tr>";
			}
		}
		return $output;
	}
	
	
		public function read_item_second($data){
		
		if($data !=''){
			$data=json_decode($data, true);
			$output='';
			foreach($data['items'] as $v){
				$id=$v['id'];
				$plato5=$v['plato5'];
				$plato6=$v['plato6'];
				$plato7=$v['plato7'];
				$plato8=$v['plato8'];
				$output.="
				<tr data-item='$id'>
					<td>$plato5</td>					
				</tr>
				<tr>
					<td>$plato6</td>
				</tr>
				<tr>
					<td>$plato7</td>
				</tr>
				<tr>
					<td>$plato8</td>
				</tr>";
			}
		}
		return $output;
	}
	
	public function read_item_third($data){
		
		if($data !=''){
			$data=json_decode($data, true);
			$output='';
			foreach($data['items'] as $v){
				$id=$v['id'];
				$plato9=$v['plato9'];
				$plato10=$v['plato10'];
				$plato11=$v['plato11'];
				$plato12=$v['plato12'];
				$output.="
				<tr data-item='$id'>
					<td>$plato9</td>					
				</tr>
				<tr>
					<td>$plato10</td>
				</tr>
				<tr>
					<td>$plato11</td>
				</tr>
				<tr>
					<td>$plato12</td>
				</tr>";
			}
		}
		return $output;
	}
	  /**
	 * Permite actualizar el item del Menu
     * 
	 *@since    1.0.0
	 *@access   private
	 *@param 	 string $data	El valor obtenido del campo 'data' con el formato JSON
	 *@param 	 string $plato1	 	Nombre del plato1
	 *@param 	 string $plato2	 	Nombre del plato2
	 *@param 	 string $plato3	 	Nombre del plato3
	 *@param 	 string $plato4	 	Nombre del plato4
	 *@param 	 string $plato5	 	Nombre del plato5
	 *@param 	 string $plato6	 	Nombre del plato6
	 *@param 	 string $plato7	 	Nombre del plato7
	 *@param 	 string $plato8	 	Nombre del plato8
	 *@param 	 string $plato9	 	Nombre del plato9
	 *@param 	 string $plato10	Nombre del plato10
	 *@param 	 string $plato11	Nombre del plato11
	 *@param 	 string $plato12	Nombre del plato12
	 */
	public function update_item($data){
		
		$ar_menu= json_decode($ar_menu, true);
		foreach ($ar_menu['items'] as $k => $v){
			$id=$v['id'];
			if($idmenu == $id){
				$ar_menu['items'][$k]['plato1'] =$plato1;
				$ar_menu['items'][$k]['plato2'] =$plato2;
				$ar_menu['items'][$k]['plato3'] =$plato3;
				$ar_menu['items'][$k]['plato4'] =$plato4;
				$ar_menu['items'][$k]['plato5'] =$plato5;
				$ar_menu['items'][$k]['plato6'] =$plato6;
				$ar_menu['items'][$k]['plato7'] =$plato7;
				$ar_menu['items'][$k]['plato8'] =$plato8;
				$ar_menu['items'][$k]['plato9'] =$plato9;
				$ar_menu['items'][$k]['plato10'] =$plato10;
				$ar_menu['items'][$k]['plato11'] =$plato11;
				$ar_menu['items'][$k]['plato12'] =$plato12;
				$ar_menu['items'][$k]['extras'] =$extras;
				$ar_menu['items'][$k]['precio'] =$precio;
				break;
				
			}
		}
		return $ar_menu;
	}
	
	
	
	public function update_item_prof($ar_plate,$idplate,$plato, $gluten,$pescado,$huevo,$soja,$lactosa,$cacahuete,$frutos,$apio,$mostaza,$sesamo,$altramuces,$moluscos,$azufre,$primeros,$segundos,$postres){
		$ar_plate=json_decode($ar_plate, true);
	
		foreach($ar_plate['items'] as $k=>$v){
				$id=$v['id'];
				if($idplate== $id){
				$ar_plate['items'][$k]['plato']=$plato;
				$ar_plate['items'][$k]['gluten']=$gluten;
				$ar_plate['items'][$k]['pescado']=$pescado;
				$ar_plate['items'][$k]['huevo']=$huevo;
				$ar_plate['items'][$k]['soja']=$soja;
				$ar_plate['items'][$k]['lactosa']=$lactosa;
				$ar_plate['items'][$k]['cacahuete']=$cacahuete;
				$ar_plate['items'][$k]['crustaceo']=$crustaceo;
				$ar_plate['items'][$k]['frutos']=$frutos;
				$ar_plate['items'][$k]['apio']=$apio;
				$ar_plate['items'][$k]['mostaza']=$mostaza;
				$ar_plate['items'][$k]['sesamo']=$sesamo;
				$ar_plate['items'][$k]['altramuces']=$altramuces;
				$ar_plate['items'][$k]['moluscos']=$moluscos;
				$ar_plate['items'][$k]['azufre']=$azufre;
				$ar_plate['items'][$k]['primeros']=$primeros;
				$ar_plate['items'][$k]['segundos']=$segundos;
				$ar_plate['items'][$k]['postres']=$postres;
				break;
			}
				
		}
		return $ar_plate;
	} 
	  /**
	 * Permite eliminar un menu
	 *
	 * @since    1.0.0
	 * @access   public
	 * @param 	 string $ar_menu	El valor obtenido del campo 'data' con el formatp JSON
	 * @param	 string $id_delete	El ID DEL item|menu que se va a eliminar
	 *
	 * @return	 array				Retorna el $ar_menu con el item|menu eliminado
	 *
	 */
	public function delete_item($ar_menu,$idmenu){
		
		$ar_menu= json_decode($ar_menu, true);
		foreach ($ar_menu['items'] as $k => $v){
			$id=$v['id'];
			if($idmenu == $id){
				unset($ar_menu['items'][$k]);
				break;
				}
			}
		return $ar_menu;
		}
		
	public function delete_plate($ar_menu, $id_delete){
		
		$ar_menu= json_decode($ar_menu, true);
		foreach ($ar_menu['items'] as $k => $v){
			$id=$v['id'];
			if($id == $id_delete){
				unset($ar_menu['items'][$k]);
				break;
				}
			}
		//$borrar=$ar_menu['items'][$id_delete];
		return $ar_menu;
	}
	
}
