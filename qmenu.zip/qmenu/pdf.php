<?php

include 'helpers/fpdf/fpdf.php';
include '../../../wp-config.php';

  class PDF extends FPDF{
	  
	  function consultarPlatos($id){
		$menu=array();
		$conexion = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME );
		$conexion->set_charset("utf8");
			try {
				$sql ="select data from `QM_TABLE` where id=".$id;
				$sentenciaPreparada = $conexion->query($sql);
				if ($sentenciaPreparada->num_rows >0) {
					while($fila= $sentenciaPreparada->fetch_assoc()){
						$menu[]=$fila;
					}
				}
			} catch ( Exception $e ) {
				$e->getMessage();
			}
		$conexion->close();
	return json_decode($menu[0]['data']);
	  }
	  
	  function  consultarExtras($id){
		$menu=array();
		$conexion = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME );
		$conexion->set_charset("utf8");
			try {
				$sql ="select comments from `QM_TABLE` where id=".$id;
				$sentenciaPreparada = $conexion->query($sql);
				if ($sentenciaPreparada->num_rows >0) {
					while($fila= $sentenciaPreparada->fetch_assoc()){
						$menu[]=$fila;
					}
				}
			} catch ( Exception $e ) {
				$e->getMessage();
			}
		$conexion->close();
	return json_decode($menu[0]['comments']);
	  }
	  
	  function primerosPlatosVertical($id){
		  $primeros=array();
		  $output="";
		  $primeros=self::consultarPlatos($id);
		 foreach($primeros as $v=>$i){
			   foreach($i as $k){
				   if($k->primeros!=null){
				  $output.=$k->plato."\n";
				   }
	
			   }
		  }
		 
		  return $output;
	  }
	  
	  
	  function segundosPlatosVertical($id){
		  $segundos=array();
		  $output="";
		  $segundos=self::consultarPlatos($id);
		 foreach($segundos as $v=>$i){
			   foreach($i as $k){
				   if($k->segundos!=null){
				  $output.=$k->plato."\n";
					
				   }
			   }
		  }
		 
		  return $output;
	  }
	  
	  function postresPlatosVertical($id){
		  $postres=array();
		  $output="";
		  $postres=self::consultarPlatos($id);
		 foreach($postres as $v=>$i){
			   foreach($i as $k){
				   if($k->postres!=null){
				  $output.=$k->plato."\n";
					
				   }
			   }
		  }
		 
		  return $output;
	  }
	  
	  function precioObservaciones($id){
		   $extras=array();
		  $output="";
		  $extras=self::consultarExtras($id);
		  
		foreach($extras as $v=>$i){
				   if($i->precio!=null){
				  		$output.=$i->precio;
				   }
			   }
		  return $output;
	  }
	  function observacionesCafe($id){
		   $extras=array();
		  $output="";
		  $extras=self::consultarExtras($id);
		  
		foreach($extras as $v=>$i){
				   if($i->cafe!=null){
				  		$output.=$i->cafe;
				   }
			   }
		  return $output;
	  }
	  
	   function observacionesBebida($id){
		   $extras=array();
		  $output="";
		  $extras=self::consultarExtras($id);
		  
		foreach($extras as $v=>$i){
				   if($i->bebida!=null){
				  		$output.=$i->bebida;
				   }
			   }
		  return $output;
	  }
	  
	   function observacionesExtras($id){
		   $extras=array();
		  $output="";
		  $extras=self::consultarExtras($id);
		  
		foreach($extras as $v=>$i){
				   if($i->extras!=null){
				  		$output.=$i->extras;
				   }
			   }
		  return $output;
	  }
	  
	   function ivaprecio($id){
		   $extras=array();
		  $output="";
		  $extras=self::consultarExtras($id);
		
		foreach($extras as $v=>$i){
				   if($i->iva!=null){
				  		$output.=$i->iva;
				   }
			   }
		   return $output;
		
	  }
  }

  
  
?>