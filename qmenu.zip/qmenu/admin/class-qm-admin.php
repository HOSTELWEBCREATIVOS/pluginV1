<?php

/**
 * La funcionalidad específica de administración del plugin.
 *
 * @link       http://hostelweb.es
 * @since      1.0.0
 *
 * @package    qmenu
 * @subpackage qmenu/admin
 */

/**
 * Define el nombre del plugin, la versión y dos métodos para
 * Encolar la hoja de estilos específica de administración y JavaScript.
 * 
 * @since      1.0.0
 * @package    qmenu
 * @subpackage qmenu/admin
 * @author     Hostelweb <info@hostelweb.es>
 * 
 * @property string $plugin_name
 * @property string $version
 */
class qm_Admin {
    
    /**
	 * El identificador único de éste plugin
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name  El nombre o identificador único de éste plugin
	 */
    private $plugin_name;
    
    /**
	 * Versión actual del plugin
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      object    $build_menupage  Instancia del objeto BC_Build_Menupage
	 */
    private $build_menupage;
	
	 /**
	 * Obejeto wpdb
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      object    $db @global $wpdb
	 */
    private $db;
	
	/**
	 * Obejeto QM_JSON
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      object    $crud Instancia del objeto QM_JSON
	 */
	private $crud_json;
	
	/**
	 * Obejeto QM_JSON
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      object    $crud Instancia del objeto QM_PRINT
	 */
    
    /**
     * @param string $plugin_name nombre o identificador único de éste plugin.
     * @param string $version La versión actual del plugin.
     */
    public function __construct( $plugin_name, $version ) {
        
        $this->plugin_name = $plugin_name;
        $this->version = $version;   
        $this->build_menupage=new qm_Build_Menupage();
		global $wpdb;
        $this->db= $wpdb;
		$this->crud_json= new QM_JSON();
	
    }
    
    /**
	 * Registra los archivos de hojas de estilos del área de administración
	 *
	 * @since    1.0.0
     * @access   public
	 */
    public function enqueue_styles($hooks) {
        
        /**
         * Una instancia de esta clase debe pasar a la función run()
         * definido en qm_Cargador como todos los ganchos se definen
         * en esa clase particular.
         *
         * El qm_Cargador creará la relación
         * entre los ganchos definidos y las funciones definidas en este
         * clase.
		*/
        /*
        * qm-admin.css
        *Archivo de estilos principales
        *de la administracion
        *
        */
        
         
        wp_enqueue_style( 'qm_wordpress_icons_css', qm_PLUGIN_DIR_URL . 'admin/css/qm-wordpress.css', array(), $this->version, 'all' );
        
        /**
        *verificamos de que siempre este en la página correcta
        */
        
        if($hooks !='toplevel_page_qm_data'){
            return;
        }
        
        
        /*
        * Framework Materializeccs
        * http://materializecss.com/getting-started.html
        * Material Icons Google
        *
        */
       	
        wp_enqueue_style( 'qm_material_icons_css','https://fonts.googleapis.com/icon?family=Material+Icons', array(), $this->version, 'all' );
        
        wp_enqueue_style( 'qm_materialize_admin_css',qm_PLUGIN_DIR_URL . 'helpers/materialize/css/materialize.min.css', array(),'0.100.1', 'all' );
        
         /*
        * Sweet Alert
        *
        *http://t4t5.github.io/sweetalert/
        */
        wp_enqueue_style( 'qm_sweet_alert_css',qm_PLUGIN_DIR_URL . 'helpers/sweetalert-master/dist/sweetalert.css', array(),$this->version, 'all' );
         
		
		
         /**
         qm-admin.css
         Archivo de hojas de estilo principipales 
         de la adinistración
         */
		wp_enqueue_style( $this->plugin_name, qm_PLUGIN_DIR_URL . 'admin/css/qm-admin.css', array(), $this->version, 'all' );
        
        
    }
    
    /**
	 * Registra los archivos Javascript del área de administración
	 *
	 * @since    1.0.0
     * @access   public
	 */
    public function enqueue_scripts($hooks) {
        
        /**
         * Una instancia de esta clase debe pasar a la función run()
         * definido en qm_Cargador como todos los ganchos se definen
         * en esa clase particular.
         *
         * El qm_Cargador creará la relación
         * entre los ganchos definidos y las funciones definidas en este
         * clase.
		 */
        
        /**
        *verificamos de que siempre este en la página correcta
        */
        
         
        
       if($hooks !='toplevel_page_qm_data'){
            return;
        }
        /*
        * Framework Materializeccs
        * http://materializecss.com/getting-started.html
        * 
        *
        */
        
       
        wp_enqueue_script( 'qm_materialize_admin_js',qm_PLUGIN_DIR_URL . 'helpers/materialize/js/materialize.min.js', ['jquery'],$this->version, true );
        
         /*
        * Sweet Alert
        *
        *http://t4t5.github.io/sweetalert/
        */
        wp_enqueue_script( 'qm_sweet_alert_js',qm_PLUGIN_DIR_URL . 'helpers/sweetalert-master/dist/sweetalert.min.js', ['jquery'],$this->version, true );
        
        wp_enqueue_script( $this->plugin_name, qm_PLUGIN_DIR_URL . 'admin/js/qm-admin.js', ['jquery'], $this->version, true );
		
		// wp_enqueue_script( $this->plugin_name, qm_PLUGIN_DIR_URL . 'helpers/fpdf/fpdf.php', ['jquery'], $this->version, true );
		
		/*
		*localizando el archivo Javascript
		*principal del áera de administracion
		*para pasarle el objeto "qmdata" con los parametros:
		*
		*@param qmdata.url Url del archivo admin-ajax
		* @param qmdata.seguridad Nonce de seguridad para el envio seguro de datos
		*/
		
		wp_localize_script(
			$this->plugin_name,
			'qmdata',
			[
				'url' => admin_url('admin-ajax.php'),
				'seguridad' => wp_create_nonce('qmdata_seg')
			]
		);
 
    }
    
    function add_menu(){
        /* método que añade el menu de nuestro plugin
        *Añadiendo el icono y las rutas 
        */
        
        $this->build_menupage->add_menu_page(
            __('Qmenu','hostelweb-textdomain'),
            __('Qmenu','hostelweb-textdomain'),
            'manage_options',
            'qm_data',
            [$this,'controlador_display_menu'],
            'dashicons-qmenu',
            22
        );
        
        $this->build_menupage->run();
    }
    /*
    * Controla las visualizaciones del menú
    *en el area de administración
    *
    * @since 1.0.0
    * @access private
    */
    public function controlador_display_menu(){
           
            if( $_GET['page']=='qm_data' && $_GET['action']=='edit' && $_GET['type']=='prof'  && isset($_GET['id'] )) {
                require_once qm_PLUGIN_DIR_PATH.'admin/partials/qm-admin-display-edit-prof.php';
        	}else{
				if( $_GET['page']=='qm_data' && $_GET['action']=='edit' && isset($_GET['id'] )) {
                	
					require_once qm_PLUGIN_DIR_PATH.'admin/partials/qm-admin-display-edit.php';
					
				}else{
					if($_GET['page']=='qm_data' && $_GET['action']=='print' && isset($_GET['id'])){
						
						
						
					}else{
						require_once qm_PLUGIN_DIR_PATH.'admin/partials/qm-admin-display.php';
					}
					
				}
            
			}
		
    	}
    
	
	/*
	*Metodo que controla el envío
	*de datos con POST,desde el lado público
	*hacia el lado del servidor
	*
	* @since 1.0.0
	* @access public
	*/
	
	public function ajaxCrudTable(){
		
		check_ajax_referer('qmdata_seg','nonce');
		if(current_user_can('manage_options')){
			extract($_POST,EXTR_OVERWRITE);
				if($tipo=='add'){
					$col=[
					'nombre'=>$nombre,
					'data'=>'',
				];
				$result=$this->db->insert(QM_TABLE,$col);
				$json=json_encode([
					'result' => $result,
					'nombre' => $nombre,
					'insert_id'=> $this->db->insert_id
				]);
			}
			
			echo $json;
			wp_die();
		}	
	}
		/*
	*Metodo que controla el envío
	*de datos con POST,desde el lado público
	*hacia el lado del servidor
	*para guardar la informacion en formato JSON
	*
	* @since 1.0.0
	* @access public
	*/
	
	public function ajaxCrudJson(){
		
		check_ajax_referer('qmdata_seg','nonce');
		if(current_user_can('manage_options')){
			extract($_POST,EXTR_OVERWRITE);
			
			$sql=$this->db->prepare("SELECT data FROM ". QM_TABLE. " WHERE id= %d ", $idtable);
			$resultado=$this->db->get_var($sql);
				if($tipo=='add'){
					
					$data=$this->crud_json->add_item($resultado, $plato1, $plato2,$plato3,$plato4,$plato5,$plato6,$plato7,$plato8,$plato9,$plato10,$plato11,$plato12,$precio,$extras);
					
					$col=[
					'data'=>json_encode($data)
					];
					
					$where=[
						"id"=>$idtable
					];
					
					$format=[
						"%s"
					];
					
					$where_format[
						"%d"
					];
					
					
				$result_update=$this->db->update( QM_TABLE, $col, $where, $format, $where_format);
					
				
				$last_item= end( $data['items'] );
					
				$insert_id=$last_item['id'];
				$json=json_encode([
					'result' => $result_update,
					'json'=> $data,
					'insert_id' =>$insert_id
					
				]);
				
			}else{
				if($tipo=='delete'){

						$where=[
							"id"=>$idtable
						];

						$where_format[
							"%d"
						];
				
					$result_delete=$this->db->delete( QM_TABLE, $where, $where_format);
					
				$json=json_encode([
					'result' => $result_delete,
					'idtable'=>$idtable
				]);
					}
			}
			echo $json;
			wp_die();
		}	
	}
    
	
	public function ajaxCrudJsonProf(){
		
		check_ajax_referer('qmdata_seg','nonce');
		if(current_user_can('manage_options')){
			extract($_POST,EXTR_OVERWRITE);
			
			$sql=$this->db->prepare("SELECT data FROM ". QM_TABLE. " WHERE id= %d ", $idtable);
			$resultado=$this->db->get_var($sql);
		
				if($tipo=='addProf'){
					
				$data=$this->crud_json->add_item_prof($resultado,$plato,$gluten,$pescado,$huevo,$soja,$lactosa,$crustaceo,$cacahuete,$frutos,$apio,$mostaza,$sesamo,$altramuces,$moluscos,$azufre,$primeros,$segundos,$postres);
				
					$col=[
					'data'=>json_encode($data)
					];
					
					$where=[
						"id"=>$idtable
					];
					
					$format=[
						"%s"
					];
					
					$where_format[
						"%d"
					];
					
					
				$result_update=$this->db->update( QM_TABLE, $col, $where, $format, $where_format);
			
				$last_item= end( $data['items'] );
					
				$insert_id=$last_item['id'];

				$json=json_encode([
					'result' => $result_update,
					'json'=> $data,
					'insert_id' =>$insert_id,
					'idplate'=>$idplate
				]);
					
			}else{
					if($tipo=='addExtras'){
						$data="";
						$data=$this->crud_json->add_comment_prof($data,$precio,$cafe,$bebida,$iva,$extras);
						$col=[
							'comments'=>json_encode($data)
						];
					
						$where=[
							"id"=>$idtable
						];

						$format=[
							"%s"
						];

						$where_format[
							"%d"
						];
					
				
						$result_update=$this->db->update( QM_TABLE, $col, $where, $format, $where_format);
						$json=json_encode([
							'observaciones'=>QM_TABLE,
							'result' => $result_update,
							'json'=> $data,
							'insert_id' =>1
						]);
					}else{
						if($tipo=='delete_plate'){
							$data=$this->crud_json->delete_plate($resultado,$idplate);
							$col=[
								'data'=>json_encode($data)
							];
							
							$where=[
							"id"=>$idtable
						];
						$format=[
							"%s"
						];

						$where_format[
							"%d"
						];
				
						
						$result_delete=$this->db->update( QM_TABLE, $col, $where, $format, $where_format);
						
						$json=json_encode([
						'result' => $data,
						'idplate'=>$idplate,
						'idtable'=>$idtable
						]);
						}
						
						if($tipo=='updateProf'){
								$data=$this->crud_json->update_item_prof($resultado,$idplate,$plato, $gluten,$pescado,$huevo,$soja,$lactosa,$cacahuete,$frutos,$apio,$mostaza,$sesamo,$altramuces,$moluscos,$azufre,$primeros,$segundos,$postres);

								$col=[
								'data'=>json_encode($data)
								];

								$where=[
									"id"=>$idtable
								];

								$format=[
									"%s"
								];

								$where_format[
									"%d"
								];


							$result_update=$this->db->update( QM_TABLE, $col, $where, $format, $where_format);


							$json=json_encode([
								'result' => $result_update,
								'json'=> $data,
								'insert_id' =>$idtable,
								'idplate'=>$idplate
							]);
							
						}
						
						}
					}
				
				}
		echo $json;
		wp_die();
		
		}
	}
		







