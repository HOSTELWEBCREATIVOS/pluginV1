<?php
/**
* Proporcionar una vista de área de administración para el plugin
* 
*Este archivo se utiliza para amrcar los aspectos de administración
*
*@since desde 1.0.0
*
*@package qmenu
*/
$sql="select id, nombre from ". QM_TABLE;
$result=$this->db->get_results($sql);

?>
	<div id="add_qm_table" class="modal">
    <div class="modal-content">
		<!-- precargador -->
		<div class="precargador">
			<div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
		</div>
		
      <form method="post">
         <div class="row">
           
            <div class="input-field col s4">
				<h6>Nombre del menú</h6>
                <input  id="platos" type="text" class="validate">
            </div>
             <div class="col s12">
                <button id="publicar" class="btn waves-effect waves-light green" type="button">
                    Publicar 
                </button>
            </div>
             </div> 
    </form>
    </div>
  </div>

<div class="had-container">
    <div class="wrap">
        <div class="col s12">
            <h1><?php echo esc_html (get_admin_page_title())?></h1>
        </div>
    
    <!-- Botón crear nueva tabla de datos-->
     <tbody>
            	<button style="margin-top:25px" class="btn waves-effect waves-light  green add-qm-table" type="button">
                   <span>Crear Menú</span> 
                </button> 
		 <div class="row">
			 	<div class="col s8" id="table-body">
					<table style="margin-top:10px"class="responsive-table bordered">
						<thead>
							<tr>
								<th>Nombre</th>
								<th>Shortcode</th>
								
							</tr>
						</thead>
						<tbody>
							<?php
								foreach($result as $i=>$v){
									
									$id=$v->id;
									$nombre=$v->nombre;
									
									echo "
								<tr data-table='$id'>
									<td>$nombre</td>
									<td>[qmdatos id=$id]</td>
									
									<td>
										<span data-qm-id-edit-prof='$id' class=' btn btn floating waves-effect waves-light blue'>
											<i class='tiny material-icons'>mode_edit</i>
										</span>
									</td>
									
									<td>
									
										<span data-qm-id-remove='$id' class='btn btn floating waves-effect red darken-1'>
										<i class='tiny material-icons'>close</i>
										</span>
									</td>
							</tr>";
								}
							?>
							
						</tbody>
					</table>
			 	</div>
		 </div>
        </tbody>
    </div>

</div>