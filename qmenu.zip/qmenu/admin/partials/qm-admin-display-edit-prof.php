<?php

/*
if( isset($_POST['prueba-form'])){
	ob_end_clean(); //    the buffer and never prints or returns anything.
	ob_start(); 
	output_vertical_pdf();
	ob_end_flush();
}

if(isset($_POST['horizontal-form'])){
	ob_end_clean();
	ob_start();
	output_horizontal_pdf();
	ob_end_flush();
}

if(isset($_POST['peq-form'])){
	ob_end_clean();
	ob_start();
	ob_end_flush();
}*/

$sql="select data from ". QM_TABLE. " where id=". $_GET['id'];
$result=$this->db->get_results($sql);
$sql1=$this->db->prepare("SELECT data FROM ". QM_TABLE. " WHERE id= %d ",  $_GET['id']);
$id="id=".$_GET['id'];

?>

<div id="addItemProfNotes_qm_table" class="modal">
	<div class="modal-content">
			<div class="precargador">
			<div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
		</div>
		<div class="row">
			<div class="input-field col s6">	
				<h6>Precio (Sólo número)</h6>
				<input id="precio" type="text" class="validate" data-length="5"/>
			</div>
			<div class="input-field col s10">
				<h6>Observaciones</h6>
				<div class="input-field col s5 fixed">
					<input type="checkbox" id="cafe" />
						<label for="cafe">Incluye café </label> 
					<input type="checkbox" id="bebida" />
						<label for="bebida">Incluye bebida y pan</label>
					<input type="checkbox" id="iva" />
						<label for="iva">Incluye IVA</label>
				</div>
			</div>
			<div class="input-field col s12">
					<h6>Extras</h6>
				<div class="input-field col s10">
					<textarea id="comentarios" class="materialize-textarea" data-length="55"></textarea>
				</div>
			</div>
			<div  class="input-field col s6">
							<p>
				<button id="finalizar" class="btn waves-effect waves-light blue" type="button">
					Finalizar
				</button></p>
			</div>
		</div>
	</div>

</div>

<div id="addUpdateProf_qm_table" class="modal" style="overflow-y: auto!important ;">
    <div class="modal-content">
		<!-- precargador -->
		<div class="precargador">
			<div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
		</div>
		
      <form method="post">
         <div class="row">
		 <h4></h4>
						<input id="idtable" type="hidden" value="<?php echo $_GET['id'] ?>" >
					 	<div class="input-field col s6">
							<h6> Nombre del plato</h6>
					 		<input id="nombrePlato" type="text" class="validate" data-length="55">
					 	</div>
					 	<div class="input-field col s12">
							<h6>Alérgenos</h6>

								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/gluten.png" height="50" width="50"/>
									<input id="gluten"  type="checkbox" value="gluten" >
									<label for="gluten">Gluten</label>
								</div>

								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/pescado.png" height="50" width="50"/>
									 <input type="checkbox" id="pescado" value="pescado" />
									<label for="pescado">Pescado</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/cristaceos.png" height="50" width="50">
									<input type="checkbox" id="crustaceo" value="crustaceo"/>
									<label for="crustaceo">Crustáceo</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/huevo.png" height="50" width="50">
									<input type="checkbox" id="huevo" value="huevo" />
									<label for="huevo">Huevo</label>
								</div>
							
							</div>
			 				<div class="input-field col s12">
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/soja.png" height="50" width="50">
									<input type="checkbox" id="soja" value="soja" />
									<label for="soja">Soja</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/leche-lactosa.png" height="50" width="50">
									<input type="checkbox" id="leche" value="lactosa" />
									<label for="leche">Lactosa</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/cacahuetes.png" height="50" width="50">
									<input type="checkbox" id="cacahuete"  value="cacahuete"/>
									<label for="cacahuete">Cacahuete</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/frutos secos.png" height="50" width="50">
									<input type="checkbox" id="frutos" value="frutos" />
									<label for="frutos">Frutos</label>
								</div>
			 				</div>
			 				<div class="input-field col s12">
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/apio.png" height="50" width="50">
									<input type="checkbox" id="apio"  value="apio"/>
									<label for="apio">Apio</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/mostaza.png" height="50" width="50">
									<input type="checkbox" id="mostaza" value="mostaza"/>
									<label for="mostaza">Mostaza</label>
								</div>
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/sesamo.png" height="50" width="50">
									<input type="checkbox" id="sesamo" value="sesamo" />
									<label for="sesamo">Sesamo</label>
								</div>

								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/atramuces.png" height="50" width="50">

									<input type="checkbox" id="altramuces" value="altramuces" />
									<label for="altramuces">Altramuces</label>
								</div>
			 				</div>
			 				<div class="input-field col s12">
								<div class="input-field col s2 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/moluscos.png" height="50" width="50">
									<input type="checkbox" id="moluscos" value ="moluscos" />
									<label for="moluscos">Moluscos</label>
								</div>
								<div class="input-field col s3 fixed">
									<img src="../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png" height="50" width="50">
									<input type="checkbox" id="azufre" value="azufre" />
									<label for="azufre">Dioxido de azufre</label>
								</div>
							</div>
						<div class="input-field col s12 fixed">
							<h6>Etiquetas</h6>
							<div class="input-field col s3">
								<input type="checkbox" id="primeros" value="primeros"/>
								<label for="primeros">Primeros</label>
							</div>
							<div class="input-field col s3">
								<input type="checkbox" id="segundos" value="segundos"/>
								<label for="segundos">Segundos</label>
							</div>
							<div class="input-field col s3">
								<input type="checkbox" id="postres" value="postres" />
								<label for="postres">Postres</label>
							</div>
							
						</div>
				
						<div  class="input-field col s6">
							<p style="margin-top:50px">
							<button id="guardarProf" class="btn waves-effect waves-light blue" type="button">
							Guardar
							</button>
							<button data-id="" id="actualizarProf" class="btn waves-effect waves-light blue" type="button">
							Actualizar
							</button></p>
						</div>
					</div>
			</form>
			 </div>	 
</div>

<div class="had-container">
    <div class="wrap">
        <div class="col s8">
            <h1><?php echo esc_html (get_admin_page_title())?></h1>
			
        </div>
 
    <!-- Botón crear nueva tabla de datos-->
     <tbody>
		 		&nbsp;&nbsp;&nbsp;<a class="btn btn-floating waves-efect waves-light black" href="?page=qm_data">
					<i class="material-icons">arrow_back</i>
		 		</a>
		 		<br>

            	<button style="margin-top:25px" class="btn waves-effect waves-light blue addItemProf" type="button">
                   <span>Agregar plato</span> 
                </button> 
		 		<button style="margin-top:25px" class="btn waves-effect waves-light blue addItemProfNotes" type="button">
                   <span> Observaciones y Extras</span> 
                </button> 
		 		
		 <div class="row">
		 		<h4>Primeros</h4>
		 			<div class="col s3">
		 			<table style="margin-top:10px"class="striped">
					
							<tr>
								<th>Nombre del plato</th>
								
							</tr>
							
						
							<td id="primerosPlatos">
							<?php
								echo $this->crud_json->read_item_prof($result);
							?>
							</td>
							
							<td  class="actually" style="position:absolute;">
								<?php
								
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
									
									foreach($items as $i){
										
										if($i->{"primeros"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a data-qm-id-plate-edit='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue'>Actualizar</a>
										</div><br>
									<?php
										}
									}
									
								}
								?>
							</td>
							<td class="actually1" style="padding-left: 100px;
    									margin-left: 100px;
    									position: absolute;">
								<?php
								
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
									foreach($items as $i){
										
										if($i->{"primeros"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a data-qm-id-plate-remove='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>
										</div><br>
									<?php
										}
									}
									
								}
								?>
							</td>
						
		 			</table>
		 			</div>
		 </div>
		 <div class="row">
			 		<div class="col s3">
						<h4>Segundos</h4>
						<table style="margin-top:10px"class="striped">
		 				
							<tr>
								<th>Nombre del plato</th>
								
							</tr>
							
						
							<td id="segundosPlatos">
							<?php
								echo $this->crud_json->read_item_prof_second($result);
							?>
							</td>
							
							<td  class="actually2" style="position:absolute;">
								<?php
								
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
									foreach($items as $i){
										
										if($i->{"segundos"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a  data-qm-id-plate-edit='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue'>Actualizar</a>
										</div><br>
									<?php
										}
									}
									
								}
								?>
							</td>
							<td  class="actually22" style="padding-left: 100px;
    									margin-left: 100px;
    									position: absolute;">
								<?php
								if (is_array($result) || is_object($result)){
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
									foreach($items as $i){
										
										if($i->{"segundos"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a  id="plato-remove" data-qm-id-plate-remove='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>
										</div><br>
									<?php
										}
									}
								}
								}
								?>
							</td>
						
		 			</table>
			 </div></div>
		 <div class="row">
			 		<div class="col s3">
						<h4>Postres</h4>
						<table style="margin-top:10px"class="striped">
		 				
							<tr >
								<th>Nombre del plato</th>
								
							</tr>
						
							<td id="postresPlatos">
							<?php
							  echo $this->crud_json->read_item_prof_third($result);
							?>
							</td>
							<td class="actually3" style="position:absolute;">
								<?php
								if (is_array($result) || is_object($result)){
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
									foreach($items as $i){
										
										if($i->{"postres"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a  data-qm-id-plate-edit='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue'>Actualizar</a>
										</div><br>
									<?php
										}
									}
									
								}
								}
								?>
							</td>
							<td class="actually33" style="padding-left: 100px;
    									margin-left: 100px;
    									position: absolute;">
								<?php
								if (is_array($result) || is_object($result)){
								foreach($result as $v ){
									$data=json_decode($v->{'data'});
									$items=$data->{"items"};
								if (is_array($result) || is_object($result)){
									foreach($items as $i){
										
										if($i->{"postres"}!=null){
											?>
											<div style='display:inline-flex;margin-bottom:25px;'>
											<a  data-qm-id-plate-remove='<?php echo $i->{'id'} ?>' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>
										</div><br>
									<?php
										}
									}
								}
								}

								}
								?>
							</td>
						
		 				</table>
			 </div></div>
		 			
		 		<a style="margin-top:25px" class="btn waves-effect waves-light blue" href="../wp-content/plugins/qmenu/imprimirVertical.php?<?php echo $id ?>" target="_blank">
                   <span> Imprimir Vertical</span> 
                </a>
				<a style="margin-top:25px" class="btn waves-effect waves-light blue" href="../wp-content/plugins/qmenu/imprimirHorizontal.php?<?php echo $id ?>" target="_blank">
                   <span> Imprimir Horizontal</span> 
                </a>
				<a style="margin-top:25px" class="btn waves-effect waves-light blue" href="../wp-content/plugins/qmenu/imprimirPequenio.php?<?php echo $id ?>" target="_blank">
                   <span> Imprimir Pequeño</span> 
                </a>
		 		
		
		</div>
    </div>

</div>