<?php
/**
* Proporcionar una vista de área de administración para el plugin
* 
*Este archivo se utiliza para amrcar los aspectos de administración
*
*@since desde 1.0.0
*
*@package qmenu
*/
$id=$_GET['id'];
$sql=$this->db->prepare("SELECT data FROM ". QM_TABLE. " WHERE id= %d ", $id);
$result=$this->db->get_var($sql);
echo "<br>Página de edición de item de las tablas de datos. ID {$_GET['id']}";
?>

	<div id="addUpdate_qm_table" class="modal">
    <div class="modal-content">
		<!-- precargador -->
		<div class="precargador">
			<div class="preloader-wrapper big active">
      <div class="spinner-layer spinner-blue">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-red">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-yellow">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>

      <div class="spinner-layer spinner-green">
        <div class="circle-clipper left">
          <div class="circle"></div>
        </div><div class="gap-patch">
          <div class="circle"></div>
        </div><div class="circle-clipper right">
          <div class="circle"></div>
        </div>
      </div>
    </div>
		</div>
		
      <form method="post">
         <div class="row">
			<div class="input-field col s4" >
				<input id="idtable" type="hidden" value="<?php echo $_GET['id'] ?>">
			<h6>Primeros platos</h6>
                <input  id="plato1" type="text" class="validate">
                 <input   id="plato2" type="text" class="validate">
                <input id="plato3" type="text" class="validate">
                <input  id="plato4" type="text" class="validate">
            </div>
             <div class="input-field col s4">
                 <h6>Segundos platos</h6>
                <input  id="plato5" type="text" class="validate">
                 <input   id="plato6" type="text" class="validate">
                 <input   id="plato7" type="text" class="validate">
                 <input   id="plato8" type="text" class="validate">
            </div>
            <div class="input-field col s4">
                 <h6>Postres</h6>
                <input   id="plato9" type="text" class="validate">
                <input   id="plato10" type="text" class="validate">
                <input   id="plato11" type="text" class="validate">
                <input  id="plato12" type="text" class="validate">
            </div>
			<div class="input-field col s4">	
				<h6>Precio</h6>
				<input id="precio" type="text" class="validate"/>
			</div>
			<div class="input-field col s6">
				<h6>Observaciones</h6>
				<div class="input-field col s5 fixed">
					<input type="checkbox" id="cafe" />
					<label for="cafe">Incluye café </label> 
				</div>
				<div class="input-field col s7 fixed">
					<input type="checkbox" id="bebida" />
					<label for="bebida">Incluye bebida y pan</label>
				</div>
				
			</div>
			<div class="input-field col s12">
					<h6>Extras</h6>
				<div class="input-field col s10">
					<textarea id="comentarios" class="materialize-textarea"></textarea>
				</div>
			</div>
             <div class="col s12">
                <button id="guardar" class="btn waves-effect waves-light green" type="button">
                    Guardar
                </button>
            </div>
          	
		</div>
    </form>
   
  </div>
</div>
		
	<div class="had-container">
    <div class="wrap">
        <div class="col s12">
            <h1><?php echo esc_html (get_admin_page_title())?></h1>
        </div>
    
    <!-- Botón crear nueva tabla de datos-->
     <tbody>
		 		&nbsp;&nbsp;&nbsp;<a class="btn btn-floating waves-efect waves-light black" href="?page=qm_data">
					<i class="material-icons">arrow_back</i>
		 		</a>
		 		<br>

            	<button style="margin-top:15px" class="btn waves-effect waves-light green addItem" type="button">
                   <span>Actualizar menu</span> 
                </button> 
		 			<!--<button data-qm-id-remove='$id' style="margin-top:15px" class='btn btn floating waves-effect red darken-1'>
					<i class='tiny material-icons'>close</i>
		 
		 		</button>-->
		</tbody>
			 <div class="row">
		 			<div class="col s8">
						
		 			<table style="margin-top:10px"class="responsive-table bordered">
		 				<thead>
							<tr>
								<th><h4>PRIMEROS</h4></th>
							</tr>
						</thead>
						<tbody>
							<?php
								echo $this->crud_json->read_item($result);
								
							?>
						</tbody>
						<thead>
							<tr>
								<th><h4>SEGUNDOS</h4></th>
							</tr>
						</thead>
						<tbody>
							<?php
								echo $this->crud_json->read_item_second($result);
								
							?>
						</tbody>
						<thead>
							<tr>
								<th><h4>POSTRES</h4></th>
							</tr>
						</thead>
						<tbody>
							<?php
								echo $this->crud_json->read_item_third($result);
								
							?>
						</tbody>
						
						
		 			</table>
					
    				</div>
    </div>

</div>
 