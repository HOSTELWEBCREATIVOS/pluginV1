( function( $ ) {
    'use strict';
/**
	 * Todo el código Javascript orientado a la administración
	 * debe estar escrito aquí
	 */	
	var $precargador=$('.precargador');
    var urledit="?page=qm_data&action=edit&id=";
	var urleditProf="?page=qm_data&action=edit&type=prof&id=";
	var urlimpProf="?page=qm_data&action=print&id=";
	var $idTable= $('#idtable').val();
	//var $idPlate=$('#plato-remove').attr('data-qm-id-plate-remove');
	
	 $('input#nombrePlato, textarea#textarea2, input#precio,textaerea#comentarios').characterCounter();
	
	
	function addMenuTable(id, plato,gluten,pescado,huevo,soja,lactosa,cacahuete,crustaceo,frutos,apio,mostaza,sesamo,altramuces,moluscos,azufre,primeros,segundos,postres){
		var clase="";
		if(primeros!=null){
			clase="primeros";
		}
		if(segundos!=null){
			clase="segundos";
		}
		if(postres!=null){
			clase="postres";
		}
		 
		 var output="<h6 data-plate='"+id+"'>\
						<div style='display:inline-flex;margin-bottom:25px;'>\
						<h6 id='plato"+id+"'type='"+clase+"'>"+plato+"</h6>";
		
		if(gluten!=null){
			
		output+="<div  id='gluten"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/gluten.png' height='25' width='25'/></div>";
		}
		if(pescado!=null){
							output+="<div  id='pescado"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/pescado.png' height='25' width='25'/></div>";
						}
						
						if(crustaceo!=null){
							output+="<div  id='cristaceos"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cristaceos.png' height='25' width='25'/></div>";
						}
						if(huevo !=null){
							output+="<div  id='huevo"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/huevo.png' height='25' width='25'/></div>";
						}
						if(soja!=null){
							output+="<div  id='soja"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/soja.png' height='25' width='25'/></div>";
						}
						if(lactosa!=null){
							output+="<div  id='lactosa"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/leche-lactosa.png' height='25' width='25'/></div>";
						}
						
						if(frutos!=null){
							output+="<div  id='frutos"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/frutos secos.png' height='25' width='25'/></div>";
						}
						if(cacahuete!=null){
							output+="<div  id='cacahute"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cacahuetes.png' height='25' width='25'/></div>";
						}
						if(apio!=null){
							output+="<div  id='apio"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/apio.png' height='25' width='25'/></div>";
						}
						if(mostaza!=null){
							output+="<div  id='mostaza"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/mostaza.png' height='25' width='25'/></div>";
						}
						if(sesamo!=null){
							output+="<div  id='sesamo"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/sesamo.png' height='25' width='25'/></div>";
						}
						
						if(altramuces!=null){
							output+="<div  id='altramuces"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/atramuces.png' height='25' width='25'/></div>";
						}
						if(moluscos!=null){
							output+="<div  id='moluscos"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/moluscos.png' height='25' width='25'/></div>";
						}
						if(azufre!=null){
							output+="<div  id='dioxido"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png' height='25' width='25'/></div>";
						}
			output+="</div></h6>";
	
		 var actually="<div style='margin-bottom:25px;'>\
							<a data-qm-id-plate-edit='"+id+"'class='waves-effect waves-light btn blue'>Actualizar</a></div>";
		var actually1="<div style='display:inline-flex;margin-bottom:25px;'>\
			<a  id='plato-remove' data-qm-id-plate-remove='"+id+"' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>\
			</div><br>"; 
		var actually2="<div style='margin-bottom:25px;'>\
							<a data-qm-id-plate-edit='"+id+"'class='waves-effect waves-light btn blue'>Actualizar</a></div>";
		var actually22="<div style='display:inline-flex;margin-bottom:25px;'>\
			<a  id='plato-remove' data-qm-id-plate-remove='"+id+"' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>\
			</div><br>";
		var actually3="<div style='margin-bottom:25px;'>\
							<a data-qm-id-plate-edit='"+id+"'class='waves-effect waves-light btn blue'>Actualizar</a></div>";
		var actually33="<div style='display:inline-flex;margin-bottom:25px;'>\
			<a  id='plato-remove' data-qm-id-plate-remove='"+id+"' class='waves-effect waves-light btn blue eliminarPlato'>Eliminar</a>\
			</div><br>";
			
			
		 if(primeros!=null){
			 $('#primerosPlatos').append(output);
			 $('.actually').append(actually);
			 $('.actually1').append(actually1);
			 
		}
		if(segundos !=null){
			 $('#segundosPlatos').append(output);
			 $('.actually2').append(actually);
			 $('.actually22').append(actually1);
		}
		if(postres !=null){
			 $('#postresPlatos').append(output);
			 $('.actually3').append(actually);
			 $('.actually33').append(actually1);
		}
	}
	
	function deleteMenu(idtable){
		 var tabla=$("tr[data-table='"+idtable+"']").text();
		$("tr[data-table='"+idtable+"']").remove();
		
		
	}
	
	function removePlate(idplate){
		var plato=$("h6[data-plate='"+idplate+"']").text();
		$(" div h6[data-plate='"+idplate+"']").remove();
		$("div a[data-qm-id-plate-edit='"+idplate+"']").remove();
		$("div a[data-qm-id-plate-remove='"+idplate+"']").remove();
	}
	
	function updatePlate(id, plato,gluten,pescado,huevo,soja,lactosa,cacahuete,crustaceo,frutos,apio,mostaza,sesamo,altramuces,moluscos,azufre,primeros,segundos,postres){
		
		var clase="";
		if(primeros!=null){
			clase="primeros";
		}
		if(segundos!=null){
			clase="segundos";
		}
		if(postres!=null){
			clase="postres";
		}
		$("#plato"+id).replaceWith("<h6 id='plato"+id+"'type='"+clase+"'>"+plato+"</h6>");
		
		if(gluten!=null){
		   $("#plato"+id).append("<div id='gluten"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/gluten.png' height='25' width='25'/></div>");
		 }else{
			 $("#gluten"+id).remove();
		 }
		if(pescado!=null){
		   $("#plato"+id).append("<div id='pescado"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/pescado.png' height='25' width='25'/></div>");
		 }else{
			 $("#pescado"+id).remove();
		 }
		
		
		if(huevo!=null){
		   $("#plato"+id).append("<div id='huevo"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/huevo.png' height='25' width='25'/></div>");
		 }else{
			 $("#huevo"+id).remove();
		 }
		
		if(soja!=null){
		   $("#plato"+id).append("<div id='soja"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/soja.png' height='25' width='25'/></div>");
		 }else{
			 $("#soja"+id).remove();
		 }
		
		if(lactosa!=null){
		   $("#plato"+id).append("<div id='lactosa"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/leche-lactosa.png' height='25' width='25'/></div>");
		 }else{
			 $("#lactosa"+id).remove();
		 }
		
		if(cacahuete!=null){
		   $("#plato"+id).append("<div id='cacahuete"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cacahuetes.png' height='25' width='25'/></div>");
		 }else{
			 $("#cacahuete"+id).remove();
		 }
		
		if(crustaceo!=null){
		   $("#plato"+id).append("<div id='crustaceo"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/cristaceos.png' height='25' width='25'/></div>");
		 }else{
			 $("#crustaceo"+id).remove();
		 }
			
		if(frutos!=null){
		   $("#plato"+id).append("<div id='frutos"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/frutos secos.png' height='25' width='25'/></div>");
		 }else{
			 $("#frutos"+id).remove();
		 }
		
		if(apio!=null){
		   $("#plato"+id).append("<div id='apio"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/apio.png' height='25' width='25'/></div>");
		 }else{
			 $("#apio"+id).remove();
		 }
		if(mostaza!=null){
		   $("#plato"+id).append("<div id='mostaza"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/mostaza.png' height='25' width='25'/></div>");
		 }else{
			 $("#mostaza"+id).remove();
		 }
		
		if(sesamo!=null){
		   $("#plato"+id).append("<div  id='sesamo"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/sesamo.png' height='25' width='25'/></div>");
		 }else{
			 $("#sesamo"+id).remove();
		 }
		
		if(altramuces!=null){
		   $("#plato"+id).append("<div id='altramuces"+id+"' style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/atramuces.png' height='25' width='25'/></div>");
		 }else{
			 $("#altramuces"+id).remove();
		 }
		
		if(moluscos!=null){
		   $("#plato"+id).append("<div  id='moluscos"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/moluscos.png' height='25' width='25'/></div>");
		 }else{
			 $("#moluscos"+id).remove();
		 }
		
		if(azufre!=null){
		   $("#plato"+id).append("<div id='azufre"+id+"'style='display:inline-flex;margin-left:5px'><img src='../wp-content/plugins/qmenu/admin/img/dioxido de azufre.png' height='25' width='25'/></div>");
		 }else{
			 $("#azufre"+id).remove();
		 }
		
		
		
	}
		
	
    $('.modal').modal();
    /*Modal para crear Tabla*/
    $( '.add-qm-table' ).on('click',function (e) {
        e.preventDefault();
        $('#add_qm_table').modal('open');
    });
    /*
    Evento click para guardar
    * el registro en la base de datos
    * utilizando ajax
    */
    
    $('#publicar').on('click',function (e){
        e.preventDefault();
        var $nombre=$('#platos'),
        nv= $nombre.val();
        if(nv !=''){
			$precargador.css('display','flex');
            //Envio de Ajax
			$.ajax({
				url: qmdata.url,
				type: 'POST',
				dataType:'json',
				data:{
					action: 'qm_qmenu_table',
					nonce: qmdata.seguridad,
					nombre: nv,
					tipo:'add'
				}, success: function(data){
						urleditProf+=data.insert_id;
						
						setTimeout(function(){
							location.href=urleditProf;
						},1300);
					
				},error: function(d,x,y){
					console.log(d);
					console.log(x);
					console.log(y);
				}				
			});
			
        }else{
			$precargador.css('display','none');
            if(! $nombre.hasClass('invalid')){
                $nombre.addClass('invalid');
            }
        }
    });
    
	//agregamos la funcionalidad de editar el menu normal
	$(document).on('click','[data-qm-id-edit]', function(){
		var id=$(this).attr('data-qm-id-edit');
		location.href=urledit+id;
		
	});
	
	//agregamos la funcionalidad de editar el menu profesional
	
	$(document).on('click','[data-qm-id-edit-prof]', function(){
		var id=$(this).attr('data-qm-id-edit-prof');
		location.href=urleditProf+id;
	});
	
	//agregamos la funcionalidad de agregar platos del modo normal
	$( '.addItem' ).on('click',function (e) {
        e.preventDefault();
        $('#addUpdate_qm_table').modal('open');
    });
	
	//agregamos la funcionalidad de observaciones y extras del modo profesional
	
	$('.addItemProfNotes').on('click',function(e){
		$('#addItemProfNotes_qm_table').modal('open');
	});
	
	$('#finalizar').on('click',function(e){
		
		e.preventDefault();
		var precio=$('#precio').val();
		if($('#cafe').is(':checked')){
			var cafe=$('#cafe').val();
		}
		if($('#bebida').is(':checked')){
			var bebida=$('#bebida').val();
		}
		if($('#iva').is(':checked')){
			var iva=$('#iva').val();
		}
		var extras=$('#comentarios').val();
		if(precio!=''){
			 $.ajax({
				url: qmdata.url,
				type: 'POST',
				cache:false,
				dataType:'json',
				data:{
					action: 'qm_qmenu_json_prof',
					nonce: qmdata.seguridad,
					tipo:'addExtras',
					idtable:$idTable,
					precio:precio,
					cafe:cafe,
					bebida:bebida,
					iva:iva,
					extras:extras
				}, success: function(data){
					console.log(data);
					if(data.result){
						swal({
							title:'Agregado',
							text: 'El precio y  las observaciones han sido agregadas correctamente',
							type:'success',
							timer: 2000
						});
						setTimeout(function(){
							$('#addItemProfNotes_qm_table').modal('close');
						},2300);
					}else{
						
						swal({
						title:"Informacion",
						text: "Hubo un problema inesperado1",
						type: "warning"
						});
						
					}
			 	
				}, error: function(data){
					
					swal({
						title:"Informacion",
						text: "Hubo un problema inesperado11",
						type: "warning"
						});
			 }
			 });
			
		}else{
			$precargador.css('display','none');
			
			if(nombrePlato==''){
            	if(! $p1.hasClass('invalid')){
                	$p1.addClass('invalid');
            	}
			}
		}
		
	});
	
	//agregamos la funcionalidad de agregar plato del modo profesional
	
	$( '.addItemProf' ).on('click',function (e) {
        e.preventDefault();
		$('#nombrePlato').val('');
			$('#gluten').prop("checked",false);
			$('#frutos').prop("checked", false);
			$('#crustaceo').prop("checked", false);
			$('#mostaza').prop("checked", false);
			$('#azufre').prop("checked", false);
			$('#altramuces').prop("checked", false);
			$('#moluscos').prop("checked", false);
			$('#sesamo').prop("checked", false);
			$('#soja').prop("checked", false);
			$('#huevo').prop("checked", false);
			$('#pescado').prop("checked", false);
			$('#cacahuete').prop("checked", false);
			$('#frutos').prop("checked", false);
			$('#apio').prop("checked", false);
			$('#leche').prop("checked", false);
			$('#primeros').prop("checked", false);
			$('#segundos').prop("checked", false);
			$('#postres').prop("checked", false);
      	$('#addUpdateProf_qm_table').modal('open');
		$('#addUpdateProf_qm_table h4').text('Agregar plato');
		$('#guardarProf').css('display','block');
		$('#actualizarProf').css('display','none');
    });
	
	
	
	$('#guardarProf').on('click',function(e){
		e.preventDefault();
		
		$('#addUpdateProf_qm_table').modal('open');
		$('#addUpdateProf_qm_table h4').text('Agregar plato');
		$('#actualizarProf').css('display','none');
		$('#guardarProf').css('display','block');
		var $p1=$('#nombrePlato');
		var nombrePlato=$p1.val();
		
		if($('#gluten').is(':checked')){
			var gluten=$('#gluten').val();
		}
		if($('#pescado').is(':checked')){
			var pescado=$('#pescado').val();
			
		}
		
		if($('#crustaceo').is(':checked')){
			var crustaceo=$('#crustaceo').val();
			
		}
		if($('#huevo').is(':checked')){
			var huevo=$('#huevo').val();
			
		}
		if($('#soja').is(':checked')){
			var soja=$('#soja').val();
			
		}
		
		if($('#leche').is(':checked')){
			var lactosa=$('#leche').val();
			
		}
		if($('#cacahuete').is(':checked')){
			var cacahuete=$('#cacahuete').val();
			
		}
		
		if($('#frutos').is(':checked')){
			var frutos=$('#frutos').val();
			
		}
		if($('#apio').is(':checked')){
			var apio=$('#apio').val();
			
		}
		if($('#mostaza').is(':checked')){
			var mostaza=$('#mostaza').val();
			
		}
		if($('#sesamo').is(':checked')){
			var sesamo=$('#sesamo').val();
		}
		if($('#altramuces').is(':checked')){
			var altramuces=$('#altramuces').val();
		}
		if($('#moluscos').is(':checked')){
			var moluscos=$('#moluscos').val();
		}
		if($('#azufre').is(':checked')){
			var azufre=$('#azufre').val();
		}
	
		if($('#primeros').is(':checked')){
			var primeros=$('#primeros').val();
		}
		if($('#segundos').is(':checked')){
			var segundos=$('#segundos').val();
		}
		if($('#postres').is(':checked')){
			var postres=$('#postres').val();
		}
	
		var obj={plato: nombrePlato};
		
		var alergeno={gluten:gluten,pescado:pescado,crustaceo:crustaceo,huevo:huevo,soja:soja,lactosa:lactosa,cacahuete:cacahuete,frutos: frutos,apio:apio,mostaza:mostaza,sesamo:sesamo,altramuces:altramuces,moluscos:moluscos,azufre:azufre
		};
		
		var categoria={ primeros:primeros,segundos:segundos,postres:postres
		};
		
		var comprobacion=false;
		if($('#primeros').is(':checked') || $('#segundos').is(':checked') ||$('#postres').is(':checked')){
				comprobacion=true;
		}else{
			comprobacion=false;
				swal({
						title:"Falta seleccionar una categoria",
						text: "Es necesario que cada plato tenga asigando una categoria. Elige entre primeros, segundos y postres",
						type: "warning"
						});
		}
		 var $this=$(this),
		 $idplate=$this.attr('data-qm-id-plate-remove');
		if(nombrePlato!='' && comprobacion==true){
			 $.ajax({
				url: qmdata.url,
				type: 'POST',
				cache:false,
				dataType:'json',
				data:{
					action: 'qm_qmenu_json_prof',
					nonce: qmdata.seguridad,
					tipo:'addProf',
					idtable:$idTable,
					idplate:$idplate,
					plato:nombrePlato,
					gluten:gluten,
					pescado:pescado,
					huevo:huevo,
					soja:soja,
					lactosa:lactosa,
					cacahuete:cacahuete,
					crustaceo:crustaceo,
					frutos:frutos,
					apio:apio,
					mostaza:mostaza,
					sesamo:sesamo,
					altramuces:altramuces,
					moluscos:moluscos,
					azufre:azufre,
					primeros:primeros,
					segundos:segundos,
					postres:postres
					
				}, success: function(data){
					console.log(data);
					if(data.result){
						swal({
							title:'Agregado',
							text: 'El menu ha sido agregado correctamente',
							type:'success',
							timer: 2000
						});
						
						setTimeout(function(){
							$('#addUpdateProf_qm_table').modal('close');
							addMenuTable(data.insert_id,nombrePlato,gluten,pescado,huevo,soja,lactosa,cacahuete,crustaceo,frutos,apio,mostaza,sesamo,altramuces,moluscos,azufre,primeros,segundos,postres);
						},1000);
						
					}else{
						
						swal({
						title:"Informacion",
						text: "Hubo un problema inesperado",
						type: "warning"
						});
						
					}
			 	
				}, error: function(data){
					swal({
						title:"Informacion",
						text: "Hubo un problema inesperado",
						type: "warning"
						});
			 }
			 });
			
		}else{
			$precargador.css('display','none');
			
			if(nombrePlato==''){
            	if(! $p1.hasClass('invalid')){
                	$p1.addClass('invalid');
            	}
			}
			
			
		}
		
	});
	
	//eliminar platos
	$(document).on('click','[data-qm-id-plate-remove]',function(){
		//alert($idPlate);
		var $this=$(this),
			idPlate=$this.attr('data-qm-id-plate-remove');
			swal({
			title:"¿Estas seguro que quieres eliminar el plato?",
			text: "No podrás deshacer esto",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor:"#DD6B55",
			confirmButtonText:"Si, borrarlo",
			closeOnConfirm:false,
			showLoaderOnConfirm: true,
			html: true
			},function(isConfirm){
				if( isConfirm){
					
				$.ajax({
				url: qmdata.url,
				type: 'POST',
				dataType:'json',
				data: {
					action: 'qm_qmenu_json_prof',
					nonce: qmdata.seguridad,
					tipo:'delete_plate',
					idplate:idPlate,
					idtable:$idTable
				}, success: function(data){
					console.log(data);
					if(data.result){
						
						$precargador.css('display','none');
							setTimeout(function(){
								swal({
									title:'Borrado',
									text: 'El plato ha sido eliminado ',
									type:'success',
									timer: 1500
								});
								removePlate(data.idplate)
							},1500);
					}else{
						$precargador.css('display','none');
						swal({
							title:'Error',
							text: 'Hubo un error al intentar eliminar el plato',
							type:'error',
							timer: 2000
						});
						console.log(data);
					}
						
					
				},error: function(data,d,y,x){
					console.log(data);
					
					
				}		
				});
				}
			});
	});
	
		
	
	
	//agregamos la funcionalidad de borrado de un menu
	
	$(document).on('click','[data-qm-id-remove]',function(){
		var $this	= $(this),
			id		= $this.attr('data-qm-id-remove');
			
		swal({
			title:"¿Estas seguro que quieres eliminar el menu?",
			text: "No podrás deshacer esto",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor:"#DD6B55",
			confirmButtonText:"Si, borrarlo",
			closeOnConfirm:false,
			showLoaderOnConfirm: true,
			html: true
		}, function(isConfirm){
			if( isConfirm){
				
				$.ajax({
				url: qmdata.url,
				type: 'POST',
				dataType:'json',
				data: {
					action: 'qm_qmenu_json',
					nonce: qmdata.seguridad,
					tipo:'delete',
					idtable:id
				}, success: function(data){
					console.log(data);
					if(data.result){
						
						$precargador.css('display','none');
							setTimeout(function(){
								swal({
									title:'Borrado',
									text: 'El menu ha sido eliminado ',
									type:'success',
									timer: 1500
								});
								deleteMenu(data.idtable);
							},1500);
						console.log(data);
						
					}else{
						$precargador.css('display','none');
						swal({
							title:'Error',
							text: 'Hubo un error al intentar eliminar el menu',
							type:'error',
							timer: 2000
						});
						console.log(data);
					}
						
					
				},error: function(data,d,y,x){
					console.log(data);
					console.log(d);
					console.log(x);
					console.log(y);
					
				}		
				});
			}
		});
	});
	
	/*actualizar platos*/
	
	$(document).on('click','[data-qm-id-plate-edit]',function(e){
		e.preventDefault();
		$('#addUpdateProf_qm_table h4').text ('Editar plato');
		$('#addUpdateProf_qm_table').modal('open');
			$('#addUpdateProf_qm_table h4').text('Editar plato');
		$('#guardarProf').css('display','none');
		$('#actualizarProf').css('display','block');
		$('#gluten').prop("checked", false);
		$('#pescado').prop("checked", false);
		$('#soja').prop("checked", false);
		$('#huevo').prop("checked", false);
		$('#leche').prop("checked", false);
		$('#crustaceo').prop("checked", false);
		$('#apio').prop("checked", false);
		$('#frutos').prop("checked", false);
		$('#cacahuete').prop("checked", false);
		$('#sesamo').prop("checked", false);
		$('#mostaza').prop("checked", false);
		$('#azufre').prop("checked", false);
		$('#molusco').prop("checked", false);
		$('#primeros').prop("checked", false);
		$('#segundos').prop("checked", false);
		$('#postres').prop("checked", false);
		var $this=$(this),
			$id=$this.attr('data-qm-id-plate-edit'),
			$parent=$this.parent().parent().parent(),
			$platoFinal='plato'+$id,
			$glutenFinal='gluten'+$id,
			$pescadoFinal='pescado'+$id,
			$sojaFinal='soja'+$id,
			$crustaceoFinal='crustaceo'+$id,
			$huevoFinal='huevo'+$id,
			$lactosaFinal='lactosa'+$id,
			$frutosFinal='frutos'+$id,
			$apioFinal='apio'+$id,
			$mostazaFinal='mostaza'+$id,
			$sesamoFinal='sesamo'+$id,
			$altraFinal='altramuces'+$id,
			$dioxidoFinal='dioxido'+$id,
			$moluscoFinal='moluscos'+$id,
			$cacahueteFinal='cacahuete'+$id,
			$primerosFinal=$('h6#'+$platoFinal).attr('type'),
			$segundosFinal='segundos',
			$postresFinal='postres',
			$plato=$parent.find("h6#"+$platoFinal),
			$gluten=$parent.find($("div#"+ $glutenFinal)).attr('id'),
			$pescado=$parent.find($("div#"+ $pescadoFinal)).attr('id'),
			$lactosa=$parent.find($("div#"+ $lactosaFinal)).attr('id'),
			$huevo=$parent.find($("div#"+ $huevoFinal)).attr('id'),
			$soja=$parent.find($("div#"+ $sojaFinal)).attr('id'),
			$crustaceo=$parent.find($("div#"+ $crustaceoFinal)).attr('id'),
			$frutos=$parent.find($("div#"+ $frutosFinal)).attr('id'),
			$apio=$parent.find($("div#"+ $apioFinal)).attr('id'),
			$sesamo=$parent.find($("div#"+ $sesamoFinal)).attr('id'),
			$altra=$parent.find($("div#"+ $altraFinal)).attr('id'),
			$dioxido=$parent.find($("div#"+ $dioxidoFinal)).attr('id'),
			$molusco=$parent.find($("div#"+ $moluscoFinal)).attr('id'),
			$cacahuete=$parent.find($("div#"+ $cacahueteFinal)).attr('id'),
			$mostaza=$parent.find($("div#"+ $mostazaFinal)).attr('id'),
			$primeros=$parent.find($("h6#"+$platoFinal)).attr('type'),
			$segundos=$parent.find($("h6#"+$platoFinal)).attr('type'),
			$postres=$parent.find($("h6#"+$platoFinal)).attr('type');
			$('#nombrePlato').val($plato.text());
		
			if($gluten==$glutenFinal){
				$('#gluten').prop("checked", true);
			}
			
			if($pescado==$pescadoFinal){
				$('#pescado').prop("checked", true);
			}
		
			if($lactosa==$lactosaFinal){
				$('#leche').prop("checked", true);
			}
			if($soja==$sojaFinal){
				$('#soja').prop("checked", true);
			}
			if($crustaceo==$crustaceoFinal){
				$('#crustaceo').prop("checked", true);
			}
			if($huevo==$huevoFinal){
				$('#huevo').prop("checked", true);
			}
			if($soja==$sojaFinal){
				$('#soja').prop("checked", true);
			}
			if($frutos==$frutosFinal){
				$('#frutos').prop("checked", true);
			}
			if($apio==$apioFinal){
				$('#apio').prop("checked", true);
			}
			if($sesamo==$sesamoFinal){
				$('#sesamo').prop("checked", true);
			}
			if($altra==$altraFinal){
				$('#altramuces').prop("checked", true);
			}
			if($dioxido==$dioxidoFinal){
				$('#azufre').prop("checked", true);
			}
			if($molusco==$moluscoFinal){
				$('#molusco').prop("checked", true);
			}
			if($cacahuete==$cacahueteFinal){
				$('#cacahuete').prop("checked", true);
			}
			if($mostaza==$mostazaFinal){
				$('#mostaza').prop("checked", true);
			}
			if($primeros=='primeros'){
				$('#primeros').prop("checked", true);
			}
			if($segundos=='segundos'){
				$('#segundos').prop("checked", true);
			}
			if($postres=='postres'){
				$('#postres').prop("checked", true);
			}
			$('#actualizarProf').attr('data-id',$id);
		});
	
	$(document).on('click','#actualizarProf',function(){
			var $this=$(this),
		    $id=$this.attr('data-id'),
			$parent=$('h6[data-user="'+$id+']'),
			$platoFinal='plato'+$id,
			$glutenFinal='gluten'+$id,
			$pescadoFinal='pescado'+$id,
			$sojaFinal='soja'+$id,
			$crustaceoFinal='crustaceo'+$id,
			$huevoFinal='huevo'+$id,
			$lactosaFinal='lactosa'+$id,
			$frutosFinal='frutos'+$id,
			$apioFinal='apio'+$id,
			$mostazaFinal='mostaza'+$id,
			$sesamoFinal='sesamo'+$id,
			$altraFinal='altramuces'+$id,
			$dioxidoFinal='dioxido'+$id,
			$moluscoFinal='moluscos'+$id,
			$cacahueteFinal='cacahuete'+$id,
			$plato=$parent.find("h6#"+$platoFinal),
			$gluten=$parent.find($("div#"+ $glutenFinal)).attr('id'),
			$pescado=$parent.find($("div#"+ $pescadoFinal)).attr('id'),
			$lactosa=$parent.find($("div#"+ $lactosaFinal)).attr('id'),
			$huevo=$parent.find($("div#"+ $huevoFinal)).attr('id'),
			$soja=$parent.find($("div#"+ $sojaFinal)).attr('id'),
			$crustaceo=$parent.find($("div#"+ $crustaceoFinal)).attr('id'),
			$frutos=$parent.find($("div#"+ $frutosFinal)).attr('id'),
			$apio=$parent.find($("div#"+ $apioFinal)).attr('id'),
			$sesamo=$parent.find($("div#"+ $sesamoFinal)).attr('id'),
			$altra=$parent.find($("div#"+ $altraFinal)).attr('id'),
			$dioxido=$parent.find($("div#"+ $dioxidoFinal)).attr('id'),
			$molusco=$parent.find($("div#"+ $moluscoFinal)).attr('id'),
			$cacahuete=$parent.find($("div#"+ $cacahueteFinal)).attr('id'),
			$mostaza=$parent.find($("div#"+ $mostazaFinal)).attr('id'),
			$primeros=$parent.find($("h6#"+$platoFinal)).attr('type'),
			$segundos=$parent.find($("h6#"+$platoFinal)).attr('type'),
			$postres=$parent.find($("h6#"+$platoFinal)).attr('type');
			var $p1=$('#nombrePlato');
			var nombrePlato=$p1.val();
		
				if($('#gluten').is(':checked')){
					var gluten=$('#gluten').val();
				}
				if($('#pescado').is(':checked')){
					var pescado=$('#pescado').val();

				}

				if($('#crustaceo').is(':checked')){
					var crustaceo=$('#crustaceo').val();

				}
				if($('#huevo').is(':checked')){
					var huevo=$('#huevo').val();

				}
				if($('#soja').is(':checked')){
					var soja=$('#soja').val();

				}

				if($('#leche').is(':checked')){
					var lactosa=$('#leche').val();

				}
				if($('#cacahuete').is(':checked')){
					var cacahuete=$('#cacahuete').val();

				}

				if($('#frutos').is(':checked')){
					var frutos=$('#frutos').val();

				}
				if($('#apio').is(':checked')){
					var apio=$('#apio').val();

				}
				if($('#mostaza').is(':checked')){
					var mostaza=$('#mostaza').val();

				}
				if($('#sesamo').is(':checked')){
					var sesamo=$('#sesamo').val();
				}
				if($('#altramuces').is(':checked')){
					var altramuces=$('#altramuces').val();
				}
				if($('#moluscos').is(':checked')){
					var moluscos=$('#moluscos').val();
				}
				if($('#azufre').is(':checked')){
					var azufre=$('#azufre').val();
				}

				if($('#primeros').is(':checked')){
					var primeros=$('#primeros').val();
				}
				if($('#segundos').is(':checked')){
					var segundos=$('#segundos').val();
				}
				if($('#postres').is(':checked')){
					var postres=$('#postres').val();
				}
				
				var obj={plato: nombrePlato};
		
		var alergeno={gluten:gluten,pescado:pescado,crustaceo:crustaceo,huevo:huevo,soja:soja,lactosa:lactosa,cacahuete:cacahuete,frutos: frutos,apio:apio,mostaza:mostaza,sesamo:sesamo,altramuces:altramuces,moluscos:moluscos,azufre:azufre
		};
		
		var categoria={ primeros:primeros,segundos:segundos,postres:postres
		};
		
		var comprobacion=false;
		if($('#primeros').is(':checked') || $('#segundos').is(':checked') ||$('#postres').is(':checked')){
				comprobacion=true;
		}else{
			comprobacion=false;
				swal({
						title:"Falta seleccionar una categoria",
						text: "Es necesario que cada plato tenga asigando una categoria. Elige entre primeros, segundos y postres",
						type: "warning"
						});
		}
		 var $this=$(this),
		 $idplate=$this.attr('data-qm-id-plate-remove');
		if(nombrePlato!='' && comprobacion==true){
			 $.ajax({
				url: qmdata.url,
				type: 'POST',
				cache:false,
				dataType:'json',
				data:{
					action: 'qm_qmenu_json_prof',
					nonce: qmdata.seguridad,
					tipo:'updateProf',
					idtable:$idTable,
					idplate:$id,
					plato:nombrePlato,
					gluten:gluten,
					pescado:pescado,
					huevo:huevo,
					soja:soja,
					lactosa:lactosa,
					cacahuete:cacahuete,
					frutos:frutos,
					apio:apio,
					mostaza:mostaza,
					sesamo:sesamo,
					altramuces:altramuces,
					moluscos:moluscos,
					azufre:azufre,
					primeros:primeros,
					segundos:segundos,
					postres:postres
					
				}, success: function(data){
					console.log(data.json);
					if(data.result){
						swal({
							title:'Agregado',
							text: 'El menu ha sido actualizado correctamente',
							type:'success',
							timer: 2000
						});
					
						
						setTimeout(function(){
							$('#addUpdateProf_qm_table').modal('close');
							 $("#gluten"+data.idplate).remove();
							 $("#huevo"+data.idplate).remove();
							 $("#soja"+data.idplate).remove();
							 $("#pescado"+data.idplate).remove();
							 $("#lactosa"+data.idplate).remove();
							 $("#cacahuete"+data.idplate).remove();
							 $("#frutos"+data.idplate).remove();
							 $("#apio"+data.idplate).remove();
							 $("#mostaza"+data.idplate).remove();
							 $("#sesamo"+data.idplate).remove();
							 $("#altramuces"+data.idplate).remove();
							 $("#moluscos"+data.idplate).remove();
							 $("#azufre"+data.idplate).remove();
							updatePlate(data.idplate,nombrePlato,gluten,pescado,huevo,soja,lactosa,cacahuete,crustaceo,frutos,apio,mostaza,sesamo,altramuces,moluscos,azufre,primeros,segundos,postres);
						},2300);
						
					}else{
						
						swal({
						title:"Informacion",
						text: "Hubo un problema inesperado",
						type: "warning"
						});
						
					}
			 	
				}, error: function(data){
					swal({
						title:"Informacion",
						text: "Hubo un problema inesperado",
						type: "warning"
						});
			 }
			 });
			
		}else{
			$precargador.css('display','none');
			
			if(nombrePlato==''){
            	if(! $p1.hasClass('invalid')){
                	$p1.addClass('invalid');
					$plato.text(nombrePlato);
            	}
			}
			
			
		}
				
	
				
			});
	
 })( jQuery );