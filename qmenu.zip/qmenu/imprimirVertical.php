<?php
require_once 'pdf.php';
ob_end_clean();
	ob_start(); 
		define('EURO',chr(128));
		$pdf = new PDF();
        $pdf->AddPage();
		$pdf->Image('admin/img/marco-menu-vertical1.jpg',7,7,195,280);
		$pdf->Image('admin/img/logo.png',140,235,30,30);
		$pdf->SetFont( 'Times', 'B', 14 );
		$pdf->Ln(20);
		$pdf->MultiCell(0,10, 'DIPONIBLE YA EN NUESTRA WEB losamigosrestaurante.es ',0 ,'C');
       	$pdf->SetFont( 'Times', 'B', 36 );
		//$pdf->SetLeftMargin (70);
		$pdf->Ln (55);
        $pdf->MultiCell(190,9, 'PRIMEROS',0 ,'C');
		$pdf->SetFont( 'Arial','', 20 );
		$pdf->Ln(5);
		categoriaPrimeros();

		$pdf->AddPage();
		$pdf->Image('admin/img/marco-menu-vertical1.jpg',7,7,195,280);
		$pdf->Image('admin/img/logo.png',140,235,30,30);
		$pdf->SetFont( 'Times', 'B', 36 );
		$pdf->Ln (30);
        $pdf->MultiCell(190,9, 'SEGUNDOS',0 ,'C');
		$pdf->Ln(5);
		$pdf->SetFont( 'Arial','', 20 );
		categoriaSegundos();
		$pdf->Ln();
		$pdf->SetFont( 'Times', 'B', 36 );
        $pdf->MultiCell(190,9, 'POSTRES',0 ,'C');
		$pdf->Ln(5);
		$pdf->SetFont( 'Arial','', 20 );
		categoriaPostres();
		$pdf->Ln(10);
		categoriaExtras();
		$pdf->Output();
		
	function categoriaPrimeros(){
		global $pdf;
		$platos=$pdf->primerosPlatosVertical($_GET['id']);

		$pdf->MultiCell (0,11,utf8_decode($platos),0,'C' );
		
		//categoriaPrimerosUno();
		 }
	
	function categoriaSegundos(){
		global $pdf;
		$platos=$pdf->segundosPlatosVertical($_GET['id']);

		$pdf->MultiCell (0,10,utf8_decode($platos),0,'C' );
		//categoriaSegundosUno();
		 }

	function categoriaPostres(){
		global $pdf;
		$platos=$pdf->postresPlatosVertical($_GET['id']);
		$pdf->MultiCell(0,10,utf8_decode($platos),0,'C');
		//categoriaPostresUno();
	}
		
		function categoriaPrimerosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
				$cnt=40;
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->primeros){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',151,$cnt,9,9);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',161,$cnt,9,9);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',171,$cnt,9,9);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',181,$cnt,9,9);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',191,$cnt,9,9);
				}
				 $cnt=$cnt+10;
						
					}
					}
				}
		}

		function categoriaSegundosUno(){
			global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuanto++;
				}
			}
			if($cuanto==3){
				$cnt=100;
			}else{
				if($cuanto==4){
				$cnt=110;
				}
				if($cuanto==2){
					$cnt=90;
				}
			}
				//$cnt=110;
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->segundos){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',151,$cnt,9,9);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',161,$cnt,9,9);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',171,$cnt,9,9);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',181,$cnt,9,9);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',191,$cnt,9,9);
				}
				 $cnt=$cnt+10;
						
					}
					}
				}
			
		}
		
		function categoriaPostresUno(){
				global $pdf;
			$primeros=$pdf->consultarPlatos($_GET['id']);
			$cuanto="";
			$cuantoPrimero="";
			foreach( $primeros->items as $v){
				if($v->segundos){
					$cuanto++;
				}
			}
			foreach( $primeros->items as $v){
				if($v->primeros){
					$cuantoPrimero++;
				}
			}
			if($cuantoPrimero==4){
			if($cuanto==3){
				$cnt=170;
			}else{
				if($cuanto==4){
				$cnt=180;
				}
				if($cuanto==2){
					$cnt=160;
				}
			}
			}
			
			if($cuantoPrimero==3){
			if($cuanto==3){
				$cnt=160;
			}else{
				if($cuanto==4){
				$cnt=170;
				}
				if($cuanto==2){
					$cnt=150;
				}
			}
			}
			
			
				foreach( $primeros->items as $v){
					$tiene="";
					if($v->id){
					if($v->postres){
					if($v->gluten!=null){
						$tiene.=":gluten";
					}
					
					if($v->pescado!=null){
						$tiene.=":pescado";
					}
					
					if($v->huevo!=null){
						$tiene.=":huevo";
					}
						if($v->soja!=null){
						$tiene.=":soja";
					}
					
					if($v->lactosa!=null){
						$tiene.=":leche-lactosa";
					}
						if($v->crustaceo!=null){
						$tiene.=":cristaceos";
					}
						if($v->cacahuete!=null){
						$tiene.=":cacahuetes";
					}
						if($v->mostaza!=null){
						$tiene.=":mostaza";
					}
						if($v->sesamo!=null){
						$tiene.=":sesamo";
					}
						if($v->frutos!=null){
						$tiene.=":frutos secos";
					}
						if($v->altramuces!=null){
						$tiene.=":atramuces";
					}
						if($v->moluscos!=null){
						
						$tiene.=":moluscos";
					}
						if($v->
						azufre!=null){
						$tiene.=":dioxido de azufre";
					}
						
				list($uno, $dos, $tres, $cuatro, $cinco, $seis, $siete) = explode(":", $tiene);
				if($uno!=""){
				$pdf->Image('admin/img/'.$uno.'.png',151,$cnt,9,9);
				}
				if($dos!=""){
				$pdf->Image('admin/img/'.$dos.'.png',161,$cnt,9,9);
				}
				if($tres!=""){
				$pdf->Image('admin/img/'.$tres.'.png',171,$cnt,9,9);
				}
				if($cuatro!=""){
				$pdf->Image('admin/img/'.$cuatro.'.png',181,$cnt,9,9);
				}
				if($cinco!=""){
				$pdf->Image('admin/img/'.$cinco.'.png',191,$cnt,9,9);
				}
				 $cnt=$cnt+10;
						
					}
					}
				}		
		}

		function categoriaExtras(){
				global $pdf;
				$pdf->SetFont( 'Arial', 'B', 40 );
				$extras=$pdf->precioObservaciones($_GET['id']);
				$pdf->MultiCell(190,10,utf8_decode($extras).EURO,0,'C');
				$cafe=$pdf->observacionesCafe($_GET['id']);
				$pdf->SetFont( 'Arial', '', 14 );
				$comentario=$pdf->observacionesExtras($_GET['id']);
				$pdf->Ln(5);
				if($comentario !=null){
					$pdf->MultiCell(190,5,utf8_decode($comentario)."",0,'C');
				}
				
			}


?>